<?php

class BMIPasien{
    public $no;
    public $bmi;
    public $tanggal;
    public $pasien;
}

?>