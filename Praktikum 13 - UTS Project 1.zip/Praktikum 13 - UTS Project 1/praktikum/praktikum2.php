<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Praktikum 2</title>

    <!-- Google Font: Source Sans Pro -->
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback"
    />
    <!-- Font Awesome -->
    <link
      rel="stylesheet"
      href="../plugins/fontawesome-free/css/all.min.css"
    />
    <!-- daterange picker -->
    <link
      rel="stylesheet"
      href="../plugins/daterangepicker/daterangepicker.css"
    />
    <!-- iCheck for checkboxes and radio inputs -->
    <link
      rel="stylesheet"
      href="../plugins/icheck-bootstrap/icheck-bootstrap.min.css"
    />
    <!-- Bootstrap Color Picker -->
    <link
      rel="stylesheet"
      href="../plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css"
    />
    <!-- Tempusdominus Bootstrap 4 -->
    <link
      rel="stylesheet"
      href="../plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css"
    />
    <!-- Select2 -->
    <link rel="stylesheet" href="../plugins/select2/css/select2.min.css" />
    <link
      rel="stylesheet"
      href="../plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css"
    />
    <!-- Bootstrap4 Duallistbox -->
    <link
      rel="stylesheet"
      href="../plugins/bootstrap4-duallistbox/bootstrap-duallistbox.min.css"
    />
    <!-- BS Stepper -->
    <link
      rel="stylesheet"
      href="../plugins/bs-stepper/css/bs-stepper.min.css"
    />
    <!-- dropzonejs -->
    <link rel="stylesheet" href="../plugins/dropzone/min/dropzone.min.css" />
    <!-- Theme style -->
    <link rel="stylesheet" href="../dist/css/adminlte.min.css" />
  </head>
  <body class="hold-transition sidebar-mini">
    <div class="wrapper">
      <!-- Navbar -->
      <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"
              ><i class="fas fa-bars"></i
            ></a>
          </li>
          <li class="nav-item d-none d-sm-inline-block">
            <a href="../." class="nav-link">Home</a>
          </li>
          <li class="nav-item d-none d-sm-inline-block">
            <a href="#" class="nav-link">Contact</a>
          </li>
        </ul>

        <!-- Right navbar links -->
        <ul class="navbar-nav ml-auto">
          <!-- Navbar Search -->
          <li class="nav-item">
            <a
              class="nav-link"
              data-widget="navbar-search"
              href="#"
              role="button"
            >
              <i class="fas fa-search"></i>
            </a>
            <div class="navbar-search-block">
              <form class="form-inline">
                <div class="input-group input-group-sm">
                  <input
                    class="form-control form-control-navbar"
                    type="search"
                    placeholder="Search"
                    aria-label="Search"
                  />
                  <div class="input-group-append">
                    <button class="btn btn-navbar" type="submit">
                      <i class="fas fa-search"></i>
                    </button>
                    <button
                      class="btn btn-navbar"
                      type="button"
                      data-widget="navbar-search"
                    >
                      <i class="fas fa-times"></i>
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </li>

          <!-- Messages Dropdown Menu -->
          <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
              <i class="far fa-comments"></i>
              <span class="badge badge-danger navbar-badge">3</span>
            </a>
            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
              <a href="#" class="dropdown-item">
                <!-- Message Start -->
                <div class="media">
                  <img
                    src="../dist/img/user1-128x128.jpg"
                    alt="User Avatar"
                    class="img-size-50 mr-3 img-circle"
                  />
                  <div class="media-body">
                    <h3 class="dropdown-item-title">
                      Brad Diesel
                      <span class="float-right text-sm text-danger"
                        ><i class="fas fa-star"></i
                      ></span>
                    </h3>
                    <p class="text-sm">Call me whenever you can...</p>
                    <p class="text-sm text-muted">
                      <i class="far fa-clock mr-1"></i> 4 Hours Ago
                    </p>
                  </div>
                </div>
                <!-- Message End -->
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item">
                <!-- Message Start -->
                <div class="media">
                  <img
                    src="../dist/img/user8-128x128.jpg"
                    alt="User Avatar"
                    class="img-size-50 img-circle mr-3"
                  />
                  <div class="media-body">
                    <h3 class="dropdown-item-title">
                      John Pierce
                      <span class="float-right text-sm text-muted"
                        ><i class="fas fa-star"></i
                      ></span>
                    </h3>
                    <p class="text-sm">I got your message bro</p>
                    <p class="text-sm text-muted">
                      <i class="far fa-clock mr-1"></i> 4 Hours Ago
                    </p>
                  </div>
                </div>
                <!-- Message End -->
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item">
                <!-- Message Start -->
                <div class="media">
                  <img
                    src="../dist/img/user3-128x128.jpg"
                    alt="User Avatar"
                    class="img-size-50 img-circle mr-3"
                  />
                  <div class="media-body">
                    <h3 class="dropdown-item-title">
                      Nora Silvester
                      <span class="float-right text-sm text-warning"
                        ><i class="fas fa-star"></i
                      ></span>
                    </h3>
                    <p class="text-sm">The subject goes here</p>
                    <p class="text-sm text-muted">
                      <i class="far fa-clock mr-1"></i> 4 Hours Ago
                    </p>
                  </div>
                </div>
                <!-- Message End -->
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item dropdown-footer"
                >See All Messages</a
              >
            </div>
          </li>
          <!-- Notifications Dropdown Menu -->
          <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
              <i class="far fa-bell"></i>
              <span class="badge badge-warning navbar-badge">15</span>
            </a>
            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
              <span class="dropdown-item dropdown-header"
                >15 Notifications</span
              >
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item">
                <i class="fas fa-envelope mr-2"></i> 4 new messages
                <span class="float-right text-muted text-sm">3 mins</span>
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item">
                <i class="fas fa-users mr-2"></i> 8 friend requests
                <span class="float-right text-muted text-sm">12 hours</span>
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item">
                <i class="fas fa-file mr-2"></i> 3 new reports
                <span class="float-right text-muted text-sm">2 days</span>
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item dropdown-footer"
                >See All Notifications</a
              >
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-widget="fullscreen" href="#" role="button">
              <i class="fas fa-expand-arrows-alt"></i>
            </a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link"
              data-widget="control-sidebar"
              data-slide="true"
              href="#"
              role="button"
            >
              <i class="fas fa-th-large"></i>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.navbar -->

      <!-- Main Sidebar Container -->
      <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <!-- Brand Logo -->
        <a href="#" class="brand-link">
          <img
            src="../dist/img/UTS projects.jpg"
            alt="UTS Projects"
            class="brand-image img-circle elevation-3"
            style="opacity: 0.8"
          />
          <span class="brand-text font-weight-light">UTS Projects</span>
        </a>

        <!-- Sidebar -->
        <div class="sidebar">
          <!-- Sidebar user (optional) -->
          <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
              <img
                src="../dist/img/safina1.jpg"
                class="img-circle elevation-2"
                alt="User Image"
              />
            </div>
            <div class="info">
              <a href="#" class="d-block">Sishafiya Syifa Safina</a>
            </div>
          </div>

          <!-- SidebarSearch Form -->
          <div class="form-inline">
            <div class="input-group" data-widget="sidebar-search">
              <input
                class="form-control form-control-sidebar"
                type="search"
                placeholder="Search"
                aria-label="Search"
              />
              <div class="input-group-append">
                <button class="btn btn-sidebar">
                  <i class="fas fa-search fa-fw"></i>
                </button>
              </div>
            </div>
          </div>

          <!-- Sidebar Menu -->
          <nav class="mt-2">
            <ul
              class="nav nav-pills nav-sidebar flex-column"
              data-widget="treeview"
              role="menu"
              data-accordion="false"
            >
              <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
              <li class="nav-item menu-open">
                <a href="#" class="nav-link">
                  <i class="nav-icon fas fa-tachometer-alt"></i>
                  <p>
                    Dashboard
                    <i class="right fas fa-angle-left"></i>
                  </p>
                </a>
                <ul class="nav nav-treeview">
                  <li class="nav-item">
                    <a href="praktikum1.php" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 1</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="praktikum2.php" class="nav-link active">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktukum 2</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="praktikum3.php" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 3</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="praktikum4.php" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 4</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="praktikum5.php" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 5</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="praktikum6.php" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 6</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 7</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 8</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 9</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 10</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 11</p>
                    </a>
                  </li>
                </ul>
              </li>
              <li class="nav-item">
                <a href="../." class="nav-link">
                  <i class="nav-icon fas fa-users"></i>
                  <p>
                    Daftar Pasien
                  </p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../kalkulatorbmi.php" class="nav-link">
                  <i class="nav-icon fas fa-th"></i>
                  <p>
                    Kalkulator BMI
                  </p>
                </a>
              </li>
              </nav>
          <!-- /.sidebar-menu -->
        </div>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
                <h1>Daftar Tugas Praktikum 2</h1>
              </div>
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active">Praktikum 2</li>
                </ol>
              </div>
            </div>
          </div>
          <!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="container-fluid">
            <div class="row">
              <!-- /.col (left) -->
              <div class="col-md-6">
                <div class="card card-primary">
                  <div class="card-body">
                      <h4>form_belanja.php</h4>
                      <!-- HTML generated using hilite.me --><div style="background: #ffffff; height: 500px; overflow:auto;width:auto;border:solid gray;border-width:.1em .1em .1em .8em;padding:.2em .6em;"><table><tr><td><pre style="margin: 0; line-height: 125%">  1
  2
  3
  4
  5
  6
  7
  8
  9
 10
 11
 12
 13
 14
 15
 16
 17
 18
 19
 20
 21
 22
 23
 24
 25
 26
 27
 28
 29
 30
 31
 32
 33
 34
 35
 36
 37
 38
 39
 40
 41
 42
 43
 44
 45
 46
 47
 48
 49
 50
 51
 52
 53
 54
 55
 56
 57
 58
 59
 60
 61
 62
 63
 64
 65
 66
 67
 68
 69
 70
 71
 72
 73
 74
 75
 76
 77
 78
 79
 80
 81
 82
 83
 84
 85
 86
 87
 88
 89
 90
 91
 92
 93
 94
 95
 96
 97
 98
 99
100
101
102
103
104
105
106
107
108
109
110
111
112
113
114
115
116
117
118
119
120
121
122
123
124
125
126
127
128
129
130
131
132</pre></td><td><pre style="margin: 0; line-height: 125%">&lt;!doctype html&gt;
&lt;html lang=&quot;en&quot;&gt;
  &lt;head&gt;
    &lt;!-- Required meta tags --&gt;
    &lt;meta charset=&quot;utf-8&quot;&gt;
    &lt;meta name=&quot;viewport&quot; content=&quot;width=device-width, initial-scale=1, shrink-to-fit=no&quot;&gt;

    &lt;!-- Bootstrap CSS --&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css&quot; integrity=&quot;sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm&quot; crossorigin=&quot;anonymous&quot;&gt;

    &lt;style&gt;
        form{
            padding: 40px 20px 50px 20px;
        }
        body{
            margin:10px;
        }
    &lt;/style&gt;

    &lt;title&gt;From Belanja&lt;/title&gt;
  &lt;/head&gt;
  &lt;body&gt;
    
    
    &lt;!-- Form --&gt;
    &lt;div&gt;
        &lt;div class=&quot;row&quot;&gt;
            &lt;div class=&quot;col-8&quot;&gt;
                &lt;!-- Navbar --&gt;
                &lt;nav class=&quot;navbar navbar-light bg-light&quot;&gt;
                    &lt;a class=&quot;navbar-brand&quot; href=&quot;#&quot;&gt;Belanja Online&lt;/a&gt;
                &lt;/nav&gt;

                &lt;form method=&quot;POST&quot; action=&quot;form_belanja.php&quot;&gt;
                &lt;div class=&quot;form-group row&quot;&gt;
                    &lt;label for=&quot;customer&quot; class=&quot;col-3 col-form-label&quot;&gt;&lt;b&gt;Customer&lt;/b&gt;&lt;/label&gt; 
                    &lt;div class=&quot;col-9&quot;&gt;
                    &lt;input id=&quot;customer&quot; name=&quot;customer&quot; placeholder=&quot;Nama Customer&quot; type=&quot;text&quot; class=&quot;form-control&quot;&gt;
                    &lt;/div&gt;
                &lt;/div&gt;
                &lt;div class=&quot;form-group row&quot;&gt;
                    &lt;label class=&quot;col-3&quot;&gt;&lt;b&gt;Pilih Produk&lt;/b&gt;&lt;/label&gt; 
                    &lt;div class=&quot;col-9&quot;&gt;
                    &lt;div class=&quot;custom-control custom-radio custom-control-inline&quot;&gt;
                        &lt;input name=&quot;produk&quot; id=&quot;produk_0&quot; type=&quot;radio&quot; class=&quot;custom-control-input&quot; value=&quot;TV&quot;&gt; 
                        &lt;label for=&quot;produk_0&quot; class=&quot;custom-control-label&quot;&gt;TV&lt;/label&gt;
                    &lt;/div&gt;
                    &lt;div class=&quot;custom-control custom-radio custom-control-inline&quot;&gt;
                        &lt;input name=&quot;produk&quot; id=&quot;produk_1&quot; type=&quot;radio&quot; class=&quot;custom-control-input&quot; value=&quot;Kulkas&quot;&gt; 
                        &lt;label for=&quot;produk_1&quot; class=&quot;custom-control-label&quot;&gt;KULKAS&lt;/label&gt;
                    &lt;/div&gt;
                    &lt;div class=&quot;custom-control custom-radio custom-control-inline&quot;&gt;
                        &lt;input name=&quot;produk&quot; id=&quot;produk_2&quot; type=&quot;radio&quot; class=&quot;custom-control-input&quot; value=&quot;Mesin Cuci&quot;&gt; 
                        &lt;label for=&quot;produk_2&quot; class=&quot;custom-control-label&quot;&gt;MESIN CUCI&lt;/label&gt;
                    &lt;/div&gt;
                    &lt;/div&gt;
                &lt;/div&gt;
                &lt;div class=&quot;form-group row&quot;&gt;
                    &lt;label for=&quot;jumlah&quot; class=&quot;col-3 col-form-label&quot;&gt;&lt;b&gt;Jumlah&lt;/b&gt;&lt;/label&gt; 
                    &lt;div class=&quot;col-9&quot;&gt;
                    &lt;input id=&quot;jumlah&quot; name=&quot;jumlah&quot; placeholder=&quot;Jumlah&quot; type=&quot;text&quot; class=&quot;form-control&quot;&gt;
                    &lt;/div&gt;
                &lt;/div&gt; 
                &lt;div class=&quot;form-group row&quot;&gt;
                    &lt;div class=&quot;offset-3 col-9&quot;&gt;
                    &lt;button name=&quot;proses&quot; type=&quot;submit&quot; class=&quot;btn btn-success&quot;&gt;Kirim&lt;/button&gt;
                    &lt;/div&gt;
                &lt;/div&gt;
                &lt;/form&gt;
            &lt;/div&gt;

            &lt;div class=&quot;col-4&quot;&gt;
                &lt;table class=&quot;table table-lg&quot;&gt;
                    &lt;thead&gt;
                        &lt;tr class=&quot;table-primary&quot;&gt;
                        &lt;th&gt;Daftar Harga&lt;/th&gt;
                        &lt;/tr&gt;
                    &lt;/thead&gt;
                    &lt;tbody&gt;
                        &lt;tr class=&quot;table-light&quot;&gt;
                        &lt;td&gt;TV : 4.200.000&lt;/td&gt;
                        &lt;/tr&gt;

                        &lt;tr class=&quot;table-light&quot;&gt;
                        &lt;td&gt;Kulkas : 3.100.000&lt;/td&gt;
                        &lt;/tr&gt;

                        &lt;tr class=&quot;table-light&quot;&gt;
                        &lt;td&gt;Mesin Cuci : 3.800.000&lt;/td&gt;
                        &lt;/tr&gt;

                        &lt;tr class=&quot;table-primary&quot;&gt;
                        &lt;th&gt;Harga Dapat Berubah Setiap Saat&lt;/th&gt;
                        &lt;/tr&gt;
                    &lt;/tbody&gt;
                &lt;/table&gt;
            &lt;/div&gt;
        &lt;/div&gt;
    &lt;/div&gt;

    &lt;hr&gt;

    &lt;!-- PHP Session --&gt;
    <span style="color: #0000ff">&lt;?php</span>

        $_customer = $_POST[<span style="color: #a31515">&quot;customer&quot;</span>];
        $_produk = $_POST[<span style="color: #a31515">&quot;produk&quot;</span>];
        $_jumlah = $_POST[<span style="color: #a31515">&quot;jumlah&quot;</span>];

        <span style="color: #0000ff">if</span> ($_produk == <span style="color: #a31515">&quot;TV&quot;</span>) {
            $harga = 4200000;
        }<span style="color: #0000ff">elseif</span>($_produk == <span style="color: #a31515">&quot;Kulkas&quot;</span>){
            $harga = 3100000;
        }<span style="color: #0000ff">elseif</span> ($_produk == <span style="color: #a31515">&quot;Mesin Cuci&quot;</span>) {
            $harga = 3800000;
        }

        <span style="color: #0000ff">echo</span> <span style="color: #a31515">&quot;Nama Customer : &quot;</span> . $_customer;
        <span style="color: #0000ff">echo</span> <span style="color: #a31515">&quot;&lt;br/&gt; Produk Pilihan : &quot;</span> . $_produk;
        <span style="color: #0000ff">echo</span> <span style="color: #a31515">&quot;&lt;br/&gt; Jumlah Beli : &quot;</span> . $_jumlah;
        <span style="color: #0000ff">echo</span> <span style="color: #a31515">&quot;&lt;br/&gt; Total Belanja : &quot;</span> . ($harga * $_jumlah);

    <span style="color: #0000ff">?&gt;</span>


    &lt;!-- Optional JavaScript --&gt;
    &lt;!-- jQuery first, then Popper.js, then Bootstrap JS --&gt;
    &lt;script src=&quot;https://code.jquery.com/jquery-3.2.1.slim.min.js&quot; integrity=&quot;sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN&quot; crossorigin=&quot;anonymous&quot;&gt;&lt;/script&gt;
    &lt;script src=&quot;https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js&quot; integrity=&quot;sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q&quot; crossorigin=&quot;anonymous&quot;&gt;&lt;/script&gt;
    &lt;script src=&quot;https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js&quot; integrity=&quot;sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl&quot; crossorigin=&quot;anonymous&quot;&gt;&lt;/script&gt;
  &lt;/body&gt;
&lt;/html&gt;
</pre></td></tr></table></div>

                      </div>
                  </div>
                </div>
              <div class="col-md-6">
                <div class="card card-primary">
                  <div class="card-body">
                      <h4>form_nilaigrade.php</h4>
                      <!-- HTML generated using hilite.me --><div style="background: #ffffff; height: 500px; overflow:auto;width:auto;border:solid gray;border-width:.1em .1em .1em .8em;padding:.2em .6em;"><table><tr><td><pre style="margin: 0; line-height: 125%">  1
  2
  3
  4
  5
  6
  7
  8
  9
 10
 11
 12
 13
 14
 15
 16
 17
 18
 19
 20
 21
 22
 23
 24
 25
 26
 27
 28
 29
 30
 31
 32
 33
 34
 35
 36
 37
 38
 39
 40
 41
 42
 43
 44
 45
 46
 47
 48
 49
 50
 51
 52
 53
 54
 55
 56
 57
 58
 59
 60
 61
 62
 63
 64
 65
 66
 67
 68
 69
 70
 71
 72
 73
 74
 75
 76
 77
 78
 79
 80
 81
 82
 83
 84
 85
 86
 87
 88
 89
 90
 91
 92
 93
 94
 95
 96
 97
 98
 99
100
101
102
103
104
105
106
107
108
109
110
111
112
113
114
115
116
117
118
119
120
121
122
123
124
125
126
127
128
129
130
131
132
133
134
135
136
137
138
139
140
141
142
143
144
145
146
147
148
149
150
151
152
153
154
155
156
157
158
159
160
161
162
163
164
165</pre></td><td><pre style="margin: 0; line-height: 125%">&lt;!DOCTYPE html&gt;

&lt;html lang=&#39;en&#39;&gt;
    &lt;head&gt;
        &lt;link rel=&quot;stylesheet&quot; href=&quot;https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css&quot;&gt; 
        &lt;link rel=&quot;stylesheet&quot; href=&quot;https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css&quot;&gt;
        &lt;title&gt;Form Nilai Mahasiswa&lt;/title&gt;
        &lt;style&gt;
            body{
                margin-top: 50px;
                margin-right: 50px;
                margin-left: 50px;
                color: #004d4d;
                background: #e6f2ff;
            }
            form{
                margin-right: 200px;
                margin-left: 200px;
            }
            .form2{
                margin-right: 50px;
                margin-left: 50px;
            }
            h3{
                text-align: center;
                color: #004d4d;
            }
        &lt;/style&gt;
    &lt;/head&gt;

    &lt;body&gt;
        &lt;h3&gt;FORM NILAI MAHASISWA&lt;/h3&gt;
        &lt;hr/&gt;&lt;br/&gt;
        &lt;form action=&quot;form_nilai_grade.php&quot; method=&quot;POST&quot;&gt;
            &lt;div class=&quot;form-group row&quot;&gt;
                &lt;label for=&quot;nama&quot; class=&quot;col-4 col-form-label&quot;&gt;&lt;b&gt;Nama Lengkap&lt;/b&gt;&lt;/label&gt; 
                &lt;div class=&quot;col-8&quot;&gt;
                &lt;div class=&quot;input-group&quot;&gt;
                    &lt;div class=&quot;input-group-prepend&quot;&gt;
                    &lt;!-- &lt;div class=&quot;input-group-text&quot;&gt;
                        &lt;i class=&quot;fa fa-address-card&quot;&gt;&lt;/i&gt;
                    &lt;/div&gt; --&gt;
                    &lt;/div&gt; 
                    &lt;input id=&quot;nama&quot; name=&quot;nama&quot; placeholder=&quot;Nama Lengkap&quot; type=&quot;text&quot; class=&quot;form-control&quot;&gt;
                &lt;/div&gt;
                &lt;/div&gt;
            &lt;/div&gt;
            &lt;div class=&quot;form-group row&quot;&gt;
                &lt;label for=&quot;matkul&quot; class=&quot;col-4 col-form-label&quot;&gt;&lt;b&gt;Mata Kuliah&lt;/b&gt;&lt;/label&gt; 
                &lt;div class=&quot;col-8&quot;&gt;
                &lt;select id=&quot;matkul&quot; name=&quot;matkul&quot; class=&quot;custom-select&quot;&gt;
                    &lt;option value=&quot;&quot;&gt;Pilih Mata Kuliah&lt;/option&gt;
                    &lt;option value=&quot;DDP&quot;&gt;Dasar-Dasar Pemrograman&lt;/option&gt;
                    &lt;option value=&quot;BD 1&quot;&gt;Basis Data I&lt;/option&gt;
                    &lt;option value=&quot;PEMWEB&quot;&gt;Pemrograman Web&lt;/option&gt;
                &lt;/select&gt;
                &lt;/div&gt;
            &lt;/div&gt;
            &lt;div class=&quot;form-group row&quot;&gt;
                &lt;label for=&quot;nilai_uts&quot; class=&quot;col-4 col-form-label&quot;&gt;&lt;b&gt;Nilai UTS&lt;/b&gt;&lt;/label&gt; 
                &lt;div class=&quot;col-8&quot;&gt;
                &lt;input id=&quot;nilai_uts&quot; name=&quot;nilai_uts&quot; placeholder=&quot;Nilai UTS&quot; type=&quot;text&quot; class=&quot;form-control&quot;&gt;
                &lt;/div&gt;
            &lt;/div&gt;
            &lt;div class=&quot;form-group row&quot;&gt;
                &lt;label for=&quot;nilai_uas&quot; class=&quot;col-4 col-form-label&quot;&gt;&lt;b&gt;Nilai UAS&lt;/b&gt;&lt;/label&gt; 
                &lt;div class=&quot;col-8&quot;&gt;
                &lt;input id=&quot;nilai_uas&quot; name=&quot;nilai_uas&quot; placeholder=&quot;Nilai UAS&quot; type=&quot;text&quot; class=&quot;form-control&quot;&gt;
                &lt;/div&gt;
            &lt;/div&gt;
            &lt;div class=&quot;form-group row&quot;&gt;
                &lt;label for=&quot;nilai_tugas&quot; class=&quot;col-4 col-form-label&quot;&gt;&lt;b&gt;Nilai Tugas/Praktikum&lt;/b&gt;&lt;/label&gt; 
                &lt;div class=&quot;col-8&quot;&gt;
                &lt;input id=&quot;nilai_tugas&quot; name=&quot;nilai_tugas&quot; placeholder=&quot;Nilai Tugas/Praktikum&quot; type=&quot;text&quot; class=&quot;form-control&quot;&gt;
                &lt;/div&gt;
            &lt;/div&gt; 
            &lt;div class=&quot;form-group row&quot;&gt;
                &lt;div class=&quot;offset-4 col-8&quot;&gt;
                &lt;button name=&quot;submit&quot; type=&quot;submit&quot; class=&quot;btn btn-primary&quot;&gt;Simpan&lt;/button&gt;
                &lt;/div&gt;
            &lt;/div&gt;
        &lt;/form&gt;
        &lt;br/&gt;&lt;hr/&gt;&lt;hr/&gt;

        <span style="color: #0000ff">&lt;?php</span>
            $_nama = isset ($_POST[<span style="color: #a31515">&#39;nama&#39;</span>]) ? $_POST[<span style="color: #a31515">&#39;nama&#39;</span>] : <span style="color: #a31515">&#39;&#39;</span>;
            $_matkul = isset ($_POST[<span style="color: #a31515">&#39;matkul&#39;</span>]) ? $_POST[<span style="color: #a31515">&#39;matkul&#39;</span>] : <span style="color: #a31515">&#39;&#39;</span>;
            $_nilai_uts = isset ($_POST[<span style="color: #a31515">&#39;nilai_uts&#39;</span>]) ? $_POST[<span style="color: #a31515">&#39;nilai_uts&#39;</span>] : <span style="color: #a31515">&#39;&#39;</span>;
            $_nilai_uas = isset ($_POST[<span style="color: #a31515">&#39;nilai_uas&#39;</span>]) ? $_POST[<span style="color: #a31515">&#39;nilai_uas&#39;</span>] : <span style="color: #a31515">&#39;&#39;</span>;
            $_nilai_tugas = isset ($_POST[<span style="color: #a31515">&#39;nilai_tugas&#39;</span>]) ? $_POST[<span style="color: #a31515">&#39;nilai_tugas&#39;</span>] : <span style="color: #a31515">&#39;&#39;</span>;
            
            <span style="color: #008000">//Perhitungan Nilai UTS (Grade)</span>

            <span style="color: #0000ff">if</span>($_nilai_uts&gt;=101){
                $_grade = <span style="color: #a31515">&quot;I&quot;</span>;
            }<span style="color: #0000ff">elseif</span>($_nilai_uts&gt;=85){
                $_grade = <span style="color: #a31515">&quot;A&quot;</span>;
            }<span style="color: #0000ff">elseif</span>($_nilai_uts&gt;=70){
                $_grade = <span style="color: #a31515">&quot;B&quot;</span>;
            }<span style="color: #0000ff">elseif</span>($_nilai_uts&gt;=56){
                $_grade = <span style="color: #a31515">&quot;C&quot;</span>;
            }<span style="color: #0000ff">elseif</span>($_nilai_uts&gt;=36){
                $_grade = <span style="color: #a31515">&quot;D&quot;</span>;
            }<span style="color: #0000ff">elseif</span>($_nilai_uts&gt;=0){
                $_grade = <span style="color: #a31515">&quot;E&quot;</span>;
            }<span style="color: #0000ff">elseif</span>($_nilai_uts&lt;=0){
                $_grade = <span style="color: #a31515">&quot;I&quot;</span>;
            }

            <span style="color: #008000">//Perhitungan Nilai UAS (Grade)</span>

            <span style="color: #0000ff">if</span>($_nilai_uas&gt;=101){
                $_grade_2 = <span style="color: #a31515">&quot;I&quot;</span>;
            }<span style="color: #0000ff">elseif</span>($_nilai_uas&gt;=85){
                $_grade_2 = <span style="color: #a31515">&quot;A&quot;</span>;
            }<span style="color: #0000ff">elseif</span>($_nilai_uas&gt;=70){
                $_grade_2 = <span style="color: #a31515">&quot;B&quot;</span>;
            }<span style="color: #0000ff">elseif</span>($_nilai_uas&gt;=56){
                $_grade_2 = <span style="color: #a31515">&quot;C&quot;</span>;
            }<span style="color: #0000ff">elseif</span>($_nilai_uas&gt;=36){
                $_grade_2 = <span style="color: #a31515">&quot;D&quot;</span>;
            }<span style="color: #0000ff">elseif</span>($_nilai_uas&gt;=0){
                $_grade_2 = <span style="color: #a31515">&quot;E&quot;</span>;
            }<span style="color: #0000ff">elseif</span>($_nilai_uas&lt;=0){
                $_grade_2 = <span style="color: #a31515">&quot;I&quot;</span>;
            }

            <span style="color: #008000">//Perhitungan Nilai Tugas/Praktikum (Grade)</span>

            <span style="color: #0000ff">if</span>($_nilai_tugas&gt;=101){
                $_grade_3 = <span style="color: #a31515">&quot;I&quot;</span>;
            }<span style="color: #0000ff">elseif</span>($_nilai_tugas&gt;=85){
                $_grade_3 = <span style="color: #a31515">&quot;A&quot;</span>;
            }<span style="color: #0000ff">elseif</span>($_nilai_tugas&gt;=70){
                $_grade_3 = <span style="color: #a31515">&quot;B&quot;</span>;
            }<span style="color: #0000ff">elseif</span>($_nilai_tugas&gt;=56){
                $_grade_3 = <span style="color: #a31515">&quot;C&quot;</span>;
            }<span style="color: #0000ff">elseif</span>($_nilai_tugas&gt;=36){
                $_grade_3 = <span style="color: #a31515">&quot;D&quot;</span>;
            }<span style="color: #0000ff">elseif</span>($_nilai_tugas&gt;=0){
                $_grade_3 = <span style="color: #a31515">&quot;E&quot;</span>;
            }<span style="color: #0000ff">elseif</span>($_nilai_tugas&lt;=0){
                $_grade_3 = <span style="color: #a31515">&quot;I&quot;</span>;
            }
        <span style="color: #0000ff">?&gt;</span>

        &lt;form class=&quot;form2&quot;&gt;
            &lt;div class=&quot;form-group row&quot;&gt;
                &lt;div class=&quot;col-6&quot;&gt;&lt;div class=&quot;col-6&quot;&gt;
                &lt;/div&gt;
                    <span style="color: #0000ff">&lt;?php</span>
                        <span style="color: #0000ff">echo</span> <span style="color: #a31515">&#39;Nama : &#39;</span>. $_nama;
                        <span style="color: #0000ff">echo</span> <span style="color: #a31515">&#39;&lt;br/&gt; Mata Kuliah : &#39;</span>. $_matkul;
                        <span style="color: #0000ff">echo</span> <span style="color: #a31515">&#39;&lt;br/&gt; Nilai UTS : &#39;</span>. $_grade;
                        <span style="color: #0000ff">echo</span> <span style="color: #a31515">&#39;&lt;br/&gt; Nilai UAS : &#39;</span>. $_grade_2;
                        <span style="color: #0000ff">echo</span> <span style="color: #a31515">&#39;&lt;br/&gt; Nilai Tugas/Praktikum : &#39;</span>. $_grade_3;
                    <span style="color: #0000ff">?&gt;</span>&lt;div class=&quot;col-6&quot;&gt;
                &lt;/div&gt;
                &lt;div class=&quot;col-6&quot;&gt;
                &lt;/div&gt;
            &lt;/div&gt;
        &lt;br&gt;&lt;hr/&gt;&lt;br/&gt;
        &lt;/form&gt;
    &lt;/body&gt;
&lt;/html&gt;
</pre></td></tr></table></div>

                      </div>
                  </div>
                </div>
              </div>
              <div class="row justify-content-center">
                  <div class="col-md">
                      <div class="card">
                          <div class="card-body">
                              <h4>form_nilaipredikat.php</h4>
                              <!-- HTML generated using hilite.me --><div style="background: #ffffff; height: 500px; overflow:auto;width:auto;border:solid gray;border-width:.1em .1em .1em .8em;padding:.2em .6em;"><table><tr><td><pre style="margin: 0; line-height: 125%">  1
  2
  3
  4
  5
  6
  7
  8
  9
 10
 11
 12
 13
 14
 15
 16
 17
 18
 19
 20
 21
 22
 23
 24
 25
 26
 27
 28
 29
 30
 31
 32
 33
 34
 35
 36
 37
 38
 39
 40
 41
 42
 43
 44
 45
 46
 47
 48
 49
 50
 51
 52
 53
 54
 55
 56
 57
 58
 59
 60
 61
 62
 63
 64
 65
 66
 67
 68
 69
 70
 71
 72
 73
 74
 75
 76
 77
 78
 79
 80
 81
 82
 83
 84
 85
 86
 87
 88
 89
 90
 91
 92
 93
 94
 95
 96
 97
 98
 99
100
101
102
103
104
105
106
107
108
109
110
111
112
113
114
115
116
117
118
119
120
121
122
123
124
125
126
127
128
129
130
131
132
133
134
135
136
137
138
139
140
141
142
143
144
145
146
147
148
149
150
151
152
153
154
155
156
157
158
159
160
161
162
163
164
165
166
167
168
169
170
171
172
173
174
175
176
177
178
179</pre></td><td><pre style="margin: 0; line-height: 125%">&lt;!DOCTYPE html&gt;

&lt;html lang=&#39;en&#39;&gt;
    &lt;head&gt;
        &lt;link rel=&quot;stylesheet&quot; href=&quot;https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css&quot;&gt; 
        &lt;link rel=&quot;stylesheet&quot; href=&quot;https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css&quot;&gt;
        &lt;title&gt;Form Nilai Mahasiswa&lt;/title&gt;
        &lt;style&gt;
            body{
                margin-top: 50px;
                margin-right: 50px;
                margin-left: 50px;
                color: #004d4d;
                background: #e6f2ff;
            }
            form{
                margin-right: 200px;
                margin-left: 200px;
            }
            .form2{
                margin-right: 50px;
                margin-left: 50px;
            }
            h3{
                text-align: center;
                color: #004d4d;
            }
        &lt;/style&gt;
    &lt;/head&gt;

    &lt;body&gt;
        &lt;h3&gt;FORM NILAI MAHASISWA&lt;/h3&gt;
        &lt;hr/&gt;&lt;br/&gt;
        &lt;form action=&quot;form_nilai_predikat.php&quot; method=&quot;GET&quot;&gt;
            &lt;div class=&quot;form-group row&quot;&gt;
                &lt;label for=&quot;nama&quot; class=&quot;col-4 col-form-label&quot;&gt;&lt;b&gt;Nama Lengkap&lt;/b&gt;&lt;/label&gt; 
                &lt;div class=&quot;col-8&quot;&gt;
                &lt;div class=&quot;input-group&quot;&gt;
                    &lt;div class=&quot;input-group-prepend&quot;&gt;
                    &lt;!-- &lt;div class=&quot;input-group-text&quot;&gt;
                        &lt;i class=&quot;fa fa-address-card&quot;&gt;&lt;/i&gt;
                    &lt;/div&gt; --&gt;
                    &lt;/div&gt; 
                    &lt;input id=&quot;nama&quot; name=&quot;nama&quot; placeholder=&quot;Nama Lengkap&quot; type=&quot;text&quot; class=&quot;form-control&quot;&gt;
                &lt;/div&gt;
                &lt;/div&gt;
            &lt;/div&gt;
            &lt;div class=&quot;form-group row&quot;&gt;
                &lt;label for=&quot;matkul&quot; class=&quot;col-4 col-form-label&quot;&gt;&lt;b&gt;Mata Kuliah&lt;/b&gt;&lt;/label&gt; 
                &lt;div class=&quot;col-8&quot;&gt;
                &lt;select id=&quot;matkul&quot; name=&quot;matkul&quot; class=&quot;custom-select&quot;&gt;
                    &lt;option value=&quot;&quot;&gt;Pilih Mata Kuliah&lt;/option&gt;
                    &lt;option value=&quot;DDP&quot;&gt;Dasar-Dasar Pemrograman&lt;/option&gt;
                    &lt;option value=&quot;BD 1&quot;&gt;Basis Data I&lt;/option&gt;
                    &lt;option value=&quot;PEMWEB&quot;&gt;Pemrograman Web&lt;/option&gt;
                &lt;/select&gt;
                &lt;/div&gt;
            &lt;/div&gt;
            &lt;div class=&quot;form-group row&quot;&gt;
                &lt;label for=&quot;nilai_uts&quot; class=&quot;col-4 col-form-label&quot;&gt;&lt;b&gt;Nilai UTS&lt;/b&gt;&lt;/label&gt; 
                &lt;div class=&quot;col-8&quot;&gt;
                &lt;input id=&quot;nilai_uts&quot; name=&quot;nilai_uts&quot; placeholder=&quot;Nilai UTS&quot; type=&quot;text&quot; class=&quot;form-control&quot;&gt;
                &lt;/div&gt;
            &lt;/div&gt;
            &lt;div class=&quot;form-group row&quot;&gt;
                &lt;label for=&quot;nilai_uas&quot; class=&quot;col-4 col-form-label&quot;&gt;&lt;b&gt;Nilai UAS&lt;/b&gt;&lt;/label&gt; 
                &lt;div class=&quot;col-8&quot;&gt;
                &lt;input id=&quot;nilai_uas&quot; name=&quot;nilai_uas&quot; placeholder=&quot;Nilai UAS&quot; type=&quot;text&quot; class=&quot;form-control&quot;&gt;
                &lt;/div&gt;
            &lt;/div&gt;
            &lt;div class=&quot;form-group row&quot;&gt;
                &lt;label for=&quot;nilai_tugas&quot; class=&quot;col-4 col-form-label&quot;&gt;&lt;b&gt;Nilai Tugas/Praktikum&lt;/b&gt;&lt;/label&gt; 
                &lt;div class=&quot;col-8&quot;&gt;
                &lt;input id=&quot;nilai_tugas&quot; name=&quot;nilai_tugas&quot; placeholder=&quot;Nilai Tugas/Praktikum&quot; type=&quot;text&quot; class=&quot;form-control&quot;&gt;
                &lt;/div&gt;
            &lt;/div&gt; 
            &lt;div class=&quot;form-group row&quot;&gt;
                &lt;div class=&quot;offset-4 col-8&quot;&gt;
                &lt;button name=&quot;submit&quot; type=&quot;submit&quot; class=&quot;btn btn-primary&quot;&gt;Simpan&lt;/button&gt;
                &lt;/div&gt;
            &lt;/div&gt;
        &lt;/form&gt;
        &lt;br/&gt;&lt;hr/&gt;&lt;hr/&gt;

        <span style="color: #0000ff">&lt;?php</span>
            $_nama = isset ($_GET[<span style="color: #a31515">&#39;nama&#39;</span>]) ? $_GET[<span style="color: #a31515">&#39;nama&#39;</span>] : <span style="color: #a31515">&#39;&#39;</span>;
            $_matkul = isset ($_GET[<span style="color: #a31515">&#39;matkul&#39;</span>]) ? $_GET[<span style="color: #a31515">&#39;matkul&#39;</span>] : <span style="color: #a31515">&#39;&#39;</span>;
            $_nilai_uts = isset ($_GET[<span style="color: #a31515">&#39;nilai_uts&#39;</span>]) ? $_GET[<span style="color: #a31515">&#39;nilai_uts&#39;</span>] : <span style="color: #a31515">&#39;&#39;</span>;
            $_nilai_uas = isset ($_GET[<span style="color: #a31515">&#39;nilai_uas&#39;</span>]) ? $_GET[<span style="color: #a31515">&#39;nilai_uas&#39;</span>] : <span style="color: #a31515">&#39;&#39;</span>;
            $_nilai_tugas = isset ($_GET[<span style="color: #a31515">&#39;nilai_tugas&#39;</span>]) ? $_GET[<span style="color: #a31515">&#39;nilai_tugas&#39;</span>] : <span style="color: #a31515">&#39;&#39;</span>;
            
            <span style="color: #008000">//Perhitungan Nilai UTS (Predikat)</span>

            <span style="color: #0000ff">switch</span>($_nilai_uts){
                <span style="color: #0000ff">case</span> <span style="color: #a31515">&#39;A&#39;</span>:
                    $info = <span style="color: #a31515">&quot;Sangat Memuaskan&quot;</span>;
                    <span style="color: #0000ff">break</span>;
                <span style="color: #0000ff">case</span> <span style="color: #a31515">&#39;B&#39;</span>:
                    $info = <span style="color: #a31515">&quot;Memuaskan&quot;</span>;
                    <span style="color: #0000ff">break</span>;
                <span style="color: #0000ff">case</span> <span style="color: #a31515">&#39;C&#39;</span>:
                    $info = <span style="color: #a31515">&quot;Cukup&quot;</span>;
                    <span style="color: #0000ff">break</span>;
                <span style="color: #0000ff">case</span> <span style="color: #a31515">&#39;D&#39;</span>:
                    $info = <span style="color: #a31515">&quot;Kurang&quot;</span>;
                    <span style="color: #0000ff">break</span>;
                <span style="color: #0000ff">case</span> <span style="color: #a31515">&#39;E&#39;</span>:
                    $info = <span style="color: #a31515">&quot;Sangat Kurang&quot;</span>;
                    <span style="color: #0000ff">break</span>;
                <span style="color: #0000ff">default</span>:
                    $info = <span style="color: #a31515">&quot;Tidak Ada&quot;</span>;
                    <span style="color: #0000ff">break</span>;
            }

            <span style="color: #008000">//Perhitungan Nilai UAS (Predikat)</span>

            <span style="color: #0000ff">switch</span>($_nilai_uas){
                <span style="color: #0000ff">case</span> <span style="color: #a31515">&#39;A&#39;</span>:
                    $info_2 = <span style="color: #a31515">&quot;Sangat Memuaskan&quot;</span>;
                    <span style="color: #0000ff">break</span>;
                <span style="color: #0000ff">case</span> <span style="color: #a31515">&#39;B&#39;</span>:
                    $info_2 = <span style="color: #a31515">&quot;Memuaskan&quot;</span>;
                    <span style="color: #0000ff">break</span>;
                <span style="color: #0000ff">case</span> <span style="color: #a31515">&#39;C&#39;</span>:
                    $info_2 = <span style="color: #a31515">&quot;Cukup&quot;</span>;
                    <span style="color: #0000ff">break</span>;
                <span style="color: #0000ff">case</span> <span style="color: #a31515">&#39;D&#39;</span>:
                    $info_2 = <span style="color: #a31515">&quot;Kurang&quot;</span>;
                    <span style="color: #0000ff">break</span>;
                <span style="color: #0000ff">case</span> <span style="color: #a31515">&#39;E&#39;</span>:
                    $info_2 = <span style="color: #a31515">&quot;Sangat Kurang&quot;</span>;
                    <span style="color: #0000ff">break</span>;
                <span style="color: #0000ff">default</span>:
                    $info_2 = <span style="color: #a31515">&quot;Tidak Ada&quot;</span>;
                    <span style="color: #0000ff">break</span>;
            }
            <span style="color: #008000">//Perhitungan Nilai Tugas/Praktikum (Predikat)</span>

            <span style="color: #0000ff">switch</span>($_nilai_tugas){
                <span style="color: #0000ff">case</span> <span style="color: #a31515">&#39;A&#39;</span>:
                    $info_3 = <span style="color: #a31515">&quot;Sangat Memuaskan&quot;</span>;
                    <span style="color: #0000ff">break</span>;
                <span style="color: #0000ff">case</span> <span style="color: #a31515">&#39;B&#39;</span>:
                    $info_3 = <span style="color: #a31515">&quot;Memuaskan&quot;</span>;
                    <span style="color: #0000ff">break</span>;
                <span style="color: #0000ff">case</span> <span style="color: #a31515">&#39;C&#39;</span>:
                    $info_3 = <span style="color: #a31515">&quot;Cukup&quot;</span>;
                    <span style="color: #0000ff">break</span>;
                <span style="color: #0000ff">case</span> <span style="color: #a31515">&#39;D&#39;</span>:
                    $info_3 = <span style="color: #a31515">&quot;Kurang&quot;</span>;
                    <span style="color: #0000ff">break</span>;
                <span style="color: #0000ff">case</span> <span style="color: #a31515">&#39;E&#39;</span>:
                    $info_3= <span style="color: #a31515">&quot;Sangat Kurang&quot;</span>;
                    <span style="color: #0000ff">break</span>;
                <span style="color: #0000ff">default</span>:
                    $info_3 = <span style="color: #a31515">&quot;Tidak Ada&quot;</span>;
                    <span style="color: #0000ff">break</span>;
            }
        <span style="color: #0000ff">?&gt;</span>

        &lt;form class=&quot;form2&quot;&gt;
            &lt;div class=&quot;form-group row&quot;&gt;
                &lt;div class=&quot;col-6&quot;&gt;&lt;div class=&quot;col-6&quot;&gt;
                &lt;/div&gt;
                    <span style="color: #0000ff">&lt;?php</span>
                        <span style="color: #0000ff">echo</span> <span style="color: #a31515">&#39;Nama : &#39;</span>. $_nama;
                        <span style="color: #0000ff">echo</span> <span style="color: #a31515">&#39;&lt;br/&gt; Mata Kuliah : &#39;</span>. $_matkul;
                        <span style="color: #0000ff">echo</span> <span style="color: #a31515">&#39;&lt;br/&gt; Nilai UTS : &#39;</span>. $info;
                        <span style="color: #0000ff">echo</span> <span style="color: #a31515">&#39;&lt;br/&gt; Nilai UAS : &#39;</span>. $info_2;
                        <span style="color: #0000ff">echo</span> <span style="color: #a31515">&#39;&lt;br/&gt; Nilai Tugas/Praktikum : &#39;</span>. $info_3;
                    <span style="color: #0000ff">?&gt;</span>&lt;div class=&quot;col-6&quot;&gt;
                &lt;/div&gt;
                &lt;div class=&quot;col-6&quot;&gt;
                &lt;/div&gt;
            &lt;/div&gt;
        &lt;br&gt;&lt;hr/&gt;&lt;br/&gt;
        &lt;/form&gt;
    &lt;/body&gt;
&lt;/html&gt;
</pre></td></tr></table></div>

                          </div>
                      </div>
                  </div>
              </div>
            </div>
              <!-- /.col (right) -->
            </div>
            </div>
        </section>
        <!-- /.content -->
      </div>
      <!-- /.content-wrapper -->
      <footer class="main-footer">
        <div class="float-right d-none d-sm-block"><b>Version</b> 3.1.0</div>
        <strong
          >Copyright &copy; 2014-2021
          <a href="https://adminlte.io">AdminLTE.io</a>.</strong
        >
        All rights reserved.
      </footer>

      <!-- Control Sidebar -->
      <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
      </aside>
      <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="../plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Select2 -->
    <script src="../plugins/select2/js/select2.full.min.js"></script>
    <!-- jquery-validation -->
    <script src="../plugins/jquery-validation/jquery.validate.min.js"></script>
    <script src="../plugins/jquery-validation/additional-methods.min.js"></script>
    <!-- Bootstrap4 Duallistbox -->
    <script src="../plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
    <!-- InputMask -->
    <script src="../plugins/moment/moment.min.js"></script>
    <script src="../plugins/inputmask/jquery.inputmask.min.js"></script>
    <!-- date-range-picker -->
    <script src="../plugins/daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap color picker -->
    <script src="../plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
    <!-- Tempusdominus Bootstrap 4 -->
    <script src="../plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
    <!-- Bootstrap Switch -->
    <script src="../plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
    <!-- BS-Stepper -->
    <script src="../plugins/bs-stepper/js/bs-stepper.min.js"></script>
    <!-- dropzonejs -->
    <script src="../plugins/dropzone/min/dropzone.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../dist/js/adminlte.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../dist/js/demo.js"></script>
    <!-- Page specific script -->
    <script src="date.js"></script>
  </body>
</html>
