<?php
    // mendefinisikan variabel
    $nama = 'Sishafiya Syifa Safina';
    $umur = 19 Tahun;
    $berat = 55 Kg;

    echo 'Nama : ' . $nama;
    echo '<br/>Umur : ' . $umur. ' Tahun';
    echo '<br/> Berat : ' . $berat. ' Kg';

    echo "<br/><br/>Hello $nama Apa kabar";

?>