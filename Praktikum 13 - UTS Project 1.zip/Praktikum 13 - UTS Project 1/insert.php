<?php
    class Insert {
        function Koneksi() {
            $koneksi = mysqli_connect("localhost", "root", "", "data");
            return $koneksi;
        }

        function savedata() {
            if (isset($_POST['kirim'])) {
                if (isset($_POST['nama']) AND
                 isset($_POST['tempatlahir']) AND
                 isset($_POST['tanggallahir']) AND
                 isset($_POST['gender']) AND 
                 isset($_POST['email']) AND 
                 isset($_POST['beratbadan']) AND 
                 isset($_POST['tinggibadan']) AND 
                 isset($_POST['nilaibmi']) AND 
                 isset($_POST['tanggalperiksa']) AND 
                 isset($_POST['statusbmi'])) {

                    $nama = $_POST['nama'];
                    $tempatlahir = $_POST['tempatlahir'];
                    $tanggallahir = $_POST['tanggallahir'];
                    $gender = $_POST['gender'];
                    $email = $_POST['email'];
                    $beratbadan = $_POST['beratbadan'];
                    $tinggibadan = $_POST['tinggibadan'];
                    $nilaibmi = $_POST['nilaibmi'];
                    $tanggalperiksa = $_POST['tanggalperiksa'];
                    $statusbmi = $_POST['statusbmi'];

                     $connect = $this->koneksi();
                     $query = mysqli_query($connect, "INSERT INTO proyek1 (
                         nama,
                         tempat_lahir,
                         tanggal_lahir,
                         email,
                         gender,
                         berat_badan,
                         tinggi_badan,
                         tanggal_periksa,
                         nilai_bmi,
                         status_bmi

                     ) VALUES (
                         '$nama',
                         '$tempatlahir',
                         '$tanggallahir',
                         '$email',
                         '$gender',
                         '$beratbadan',
                         '$tinggibadan',
                         '$tanggalperiksa',
                         '$nilaibmi',
                         '$statusbmi'

                         )");

                         if ($query === true) {
                             echo'<script>
                             alert("Data Berhasil Ditambahkan!");
                             document.location.href = ".";
                                  </script>';
                         } else {
                            echo'<script>
                            alert("Data Gagal Ditambahkan!");
                            document.location.href = ".";
                                 </script>';
                         }
                }
            }
        }
    }

    $masuk = new Insert();
    $masuk -> savedata();

?>