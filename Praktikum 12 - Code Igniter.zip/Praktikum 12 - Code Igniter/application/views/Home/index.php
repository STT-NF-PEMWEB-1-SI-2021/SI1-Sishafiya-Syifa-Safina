<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>STT NF</title>

    <style>
        table{
            text-align: center;
        }
    </style>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css')?>" >
    <!-- Icon -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fonts/line-icons.css')?>">
    <!-- Owl carousel -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/owl.carousel.min.css')?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/owl.theme.css')?>">
    
    <!-- Animate -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/animate.css')?>">
    <!-- Main Style -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/main.css')?>">
    <!-- Responsive Style -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/responsive.css')?>">

  </head>
  <body>

    <!-- Header Area wrapper Starts -->
    <header id="header-wrap">
      <!-- Navbar Start -->
      <nav class="navbar navbar-expand-md bg-inverse fixed-top scrolling-navbar">
        <div class="container">
          <!-- Brand and toggle get grouped for better mobile display -->
          <a href="index.html" class="navbar-brand"><img src="<?php echo base_url('assets/img/logoNF.png')?>" alt=""></a>       
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
            <i class="lni-menu"></i>
          </button>
          <div class="collapse navbar-collapse" id="navbarCollapse">
            <ul class="navbar-nav mr-auto w-100 justify-content-end clearfix">
              <li class="nav-item active">
                <a class="nav-link" href="#hero-area">
                  Home
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#visi">
                  Visi & Misi
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#tujuan">
                  Tujuan
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#mahasiswa">
                  Mahasiswa
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#dosen">
                  Dosen
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#prodi">
                  Program Studi
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#contact">
                  Contact
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <!-- Navbar End -->

      <!-- Hero Area Start -->
      <div id="hero-area" class="hero-area-bg">
        <div class="container">      
          <div class="row">
            <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12">
              <div class="contents">
                <h2 class="head-title">Sekolah Tinggi Teknologi Terpadu Nurul Fikri</h2>
                <p>Sekolah Tinggi Teknologi Terpadu Nurul Fikri (populer disebut STT-NF) merupakan perguruan tinggi yang memadukan keilmuan praktis di bidang teknologi informasi dengan pengembangan kepribadian islami, kompeten dan berkarakter. Pada tahun 2012, STT-NF resmi berdiri berdasarkan SK Menteri Pendidikan dan Kebudayaan Nomor 269/E/O/2012.</p>
                <div class="header-button">
                  <a href="login" class="btn btn-common">Login</i></a>
                </div>
              </div>
            </div>
            <div class="col-lg-5 col-md-12 col-sm-12 col-xs-12">
              <div class="intro-img">
                <img class="img-fluid" src="<?php echo base_url('assets/img/sttnf.jpg')?>" alt="">
              </div>            
            </div>
          </div> 
        </div> 
      </div>
      <!-- Hero Area End -->

    </header>
    <!-- Header Area wrapper End -->

     <!-- About Section start -->
     <div id="visi" class="about-area section-padding">
      <div class="container">
        <div class="section-header text-center">          
          <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">VISI</h2>
          <div class="shape wow fadeInDown" data-wow-delay="0.3s"></div>
        </div>
        <div class="row content-center">
          <div class="col-md-12">
            <p>“Pada tahun 2045 menjadi Sekolah Tinggi Teknologi yang unggul di Indonesia, berbudaya inovasi, berjiwa teknopreneur, dan berkarakter religius.”</p>
          </div>
        </div>
      </div>
    </div>
    <!-- About Section End -->

    <!-- About Section start -->
    <div id="misi" class="about-area section-padding">
      <div class="container">
        <div class="section-header text-center">          
          <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">MISI</h2>
          <div class="shape wow fadeInDown" data-wow-delay="0.3s"></div>
        </div>
        <div class="row content-center">
          <div class="col-md-12">
            1. Menyelenggarakan pendidikan tinggi berkualitas yang mengembangkan jiwa kepemimpinan dan teknopreneurship berlandaskan iman dan takwa.
            <br>
            2. Melaksanakan penelitian yang inovatif dan berorientasi pada pengembangan teknologi masa depan.
            <br>
            3. Menyelenggarakan pengabdian kepada masyarakat dengan memanfaatkan teknologi tepat guna.
            <br>
            4. Membangun lingkungan akademik yang kondusif bagi terwujudnya kebebasan akademik, otonomi keilmuan, dan budaya inovasi.
          </div>
        </div>
      </div>
    </div>
    <!-- About Section End -->

    <!-- About Section start -->
    <div id="tujuan" class="about-area section-padding bg-gray">
      <div class="container">
        <div class="section-header text-center">          
          <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">TUJUAN</h2>
          <div class="shape wow fadeInDown" data-wow-delay="0.3s"></div>
        </div>
        <div class="row content-center">
          <div class="col-md-12">
            1. Menghasilkan sarjana yang kompeten, profesional, berakhlak mulia, sehingga mampu berkompetisi di dunia kerja.
            <br>
            2. Menghasilkan karya-karya ilmiah dibidang teknologi informasi berwawasan masa depan yang inovatif dan bercirikan keterbukaan (openness) seperti open source, open standar dan open access/content, sehingga bermanfaat bagi bangsa Indonesia dan diakui secara Internasional.
            <br>
            3. Menerapkan ilmu pengetahuan dan teknologi tepat guna bagi masyarakat dengan melibatkan sivitas akademika.
            <br>
            4. Menciptakan kultur akademik yang inovatif, kompetitif dan kondusif untuk mewujudkan institusi yang unggul dan terkemuka.
          </div>
        </div>
      </div>
    </div>
    <!-- About Section End -->

    <!-- Services Section Start -->
    <section id="mahasiswa" class="section-padding">
      <div class="container">
        <div class="section-header text-center">          
          <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">DAFTAR MAHASISWA</h2>
          <div class="shape wow fadeInDown" data-wow-delay="0.3s"></div>
        </div>
        <div class="row justify-content-center">
          <div class="col-sm-12">
            <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">NIM</th>
                    <th scope="col">Nama Mahasiswa</th>
                    <th scope="col">Gender</th>
                    <th scope="col">Program Studi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $nomor = 1;
                    foreach($list_mahasiswa as $obj){
                ?>

                <tr>
                    <td><?= $nomor ?></th>
                    <td><?= $obj -> nim ?></td>
                    <td><?= $obj -> nama ?></td>
                    <td><?= $obj-> gender ?></td>
                    <td><?= $obj -> prodi?></td>
                </tr>

                <?php
                    $nomor++;
                    }
                ?>
            </tbody>
        </table>
        </div>
        </div>
      </div>
    </section>
    <!-- Services Section End -->

    <!-- Features Section Start -->
    <section id="dosen" class="section-padding bg-gray">
      <div class="container">
        <div class="section-header text-center">          
          <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">DAFTAR DOSEN</h2>
          <div class="shape wow fadeInDown" data-wow-delay="0.3s"></div>
        </div>
        <div class="row justify-content-center">
          <div class="col-sm-12">
          <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">NIDN</th>
                    <th scope="col">Nama Dosen</th>
                    <th scope="col">Program Studi</th>
                </tr>
            </thead>
            <tbody>

                <?php
                    $nomor = 1;
                    foreach($list_dosen as $dosen){
                ?>

                <tr>
                    <td><?= $nomor ?></td>
                    <td><?= $dosen->nidn ?></td>
                    <td><?= $dosen->nama_dosen ?></td>
                    <td><?= $dosen->prodi_kode ?></td>
                </tr>
                
                <?php
                    $nomor++;
                    }
                ?>
            </tbody>
        </table>
          </div>
        </div>
      </div>
    </section>
    <!-- Features Section End -->   

    <!-- Team Section Start -->
    <section id="prodi" class="section-padding">
      <div class="container">
        <div class="section-header text-center">          
          <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">DAFTAR PROGRAM STUDI</h2>
          <div class="shape wow fadeInDown" data-wow-delay="0.3s"></div>
        </div>
        <div class="row">
          <div class="col-md-12">
          <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Kode</th>
                    <th scope="col">Nama Prodi</th>
                    <th scope="col">Kapala Program Studi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $nomor = 1;
                    foreach($list_prodi as $prodi){
                ?>

                <tr>
                    <td><?= $nomor ?></th>
                    <td><?= $prodi -> kode ?></td>
                    <td><?= $prodi -> nama_prodi ?></td>
                    <td><?= $prodi -> kaprodi ?></td>
                </tr>
                
                <?php
                    $nomor++;
                    }
                ?>
            </tbody>
        </table>
          </div>
        </div>
      </div>
    </section>
    <!-- Team Section End -->

    <!-- Testimonial Section Start -->
    <section id="pengumuman" class="section-padding bg-gray">
      <div class="container">
        <div class="section-header text-center">          
          <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">PENGUMUMAN<br></h2>
          <div class="shape wow fadeInDown" data-wow-delay="0.3s"></div>
        </div>
        <div class="row justify-content-center">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div id="testimonials" class="owl-carousel wow fadeInUp" data-wow-delay="1.2s">
              <div class="item">
                <div class="testimonial-item">
                  <div class="img-thumb">
                    <img src="<?php echo base_url('assets/img/pengumuman4.png')?>" alt="">
                  </div>
                  <div class="info">
                    <h2><a href="https://nurulfikri.ac.id/kalender-akademik/">Kalender Akademik Tahun Pembelajaran 2020/2021</a></h2>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimonial-item">
                  <div class="img-thumb">
                    <img src="<?php echo base_url('assets/img/pengumuman2.png')?>" alt="">
                  </div>
                  <div class="info">
                    <h2><a href="#">Pendaftaran Mahasiswa Baru</a></h2>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimonial-item">
                  <div class="img-thumb">
                    <img src="<?php echo base_url('assets/img/pengumuman1.png')?>" alt="">
                  </div>
                  <div class="info">
                    <h2><a href="https://drive.google.com/file/d/1rikOcgpq4zd3VMAis-0_WEqPlvejDqBB/view">Penerimaan Beasiswa UKT</a></h2>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimonial-item">
                  <div class="img-thumb">
                    <img src="<?php echo base_url('assets/img/pengumuman3.png')?>" alt="">
                  </div>
                  <div class="info">
                    <h2><a href="https://elena.nurulfikri.ac.id/">Proses Pembelajaran Daring</a></h2>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Testimonial Section End -->

    <!-- Contact Section Start -->
    <section id="contact" class="section-padding">    
      <div class="container">
        <div class="section-header text-center">          
          <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">Contact</h2>
          <div class="shape wow fadeInDown" data-wow-delay="0.3s"></div>
        </div>
        <div class="row contact-form-area wow fadeInUp" data-wow-delay="0.3s">   
          <div class="col-lg-7 col-md-12 col-sm-12">
            <div class="contact-block">
              <form id="contactForm">
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <input type="text" class="form-control" id="name" name="name" placeholder="Name" required data-error="Please enter your name">
                      <div class="help-block with-errors"></div>
                    </div>                                 
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <input type="text" placeholder="Email" id="email" class="form-control" name="email" required data-error="Please enter your email">
                      <div class="help-block with-errors"></div>
                    </div> 
                  </div>
                   <div class="col-md-12">
                    <div class="form-group">
                      <input type="text" placeholder="Subject" id="msg_subject" class="form-control" required data-error="Please enter your subject">
                      <div class="help-block with-errors"></div>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group"> 
                      <textarea class="form-control" id="message" placeholder="Pesan" rows="7" data-error="Write your message" required></textarea>
                      <div class="help-block with-errors"></div>
                    </div>
                    <div class="submit-button text-left">
                      <button class="btn btn-common" id="form-submit" type="submit">Kirim Pesan</button>
                      <div id="msgSubmit" class="h3 text-center hidden"></div> 
                      <div class="clearfix"></div> 
                    </div>
                  </div>
                </div>            
              </form>
            </div>
          </div>
          <div class="col-lg-5 col-md-12 col-xs-12">
            <div class="map">
              <object style="border:0; height: 280px; width: 100%;" data="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.3172397557187!2d106.83028601413899!3d-6.3529609639189895!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69ec6b07b68ea5%3A0x17da46bdf9308386!2sSTT%20Terpadu%20Nurul%20Fikri%20-%20Kampus%20B!5e0!3m2!1sen!2sid!4v1656056689818!5m2!1sen!2sid"></object>
            </div>
          </div>
        </div>
      </div> 
    </section>
    <!-- Contact Section End -->

    <!-- Footer Section Start -->
    <footer id="footer" class="footer-area section-padding">
      <div class="container">
        <div class="container">
          <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-6 col-mb-12">
              <div class="widget">
                <h3 class="footer-logo"><img src="<?php echo base_url('assets/img/logoNF.png')?>" alt=""></h3>
                <div class="textwidget">
                <p>Kampus STT Terpadu Nurul Fikri</p>
                </div>
                <div class="social-icon">
                  <a class="facebook" href="#"><i class="lni-facebook-filled"></i></a>
                  <a class="twitter" href="#"><i class="lni-twitter-filled"></i></a>
                  <a class="instagram" href="#"><i class="lni-instagram-filled"></i></a>
                  <a class="linkedin" href="#"><i class="lni-linkedin-filled"></i></a>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
              <h3 class="footer-titel">Resources</h3>
              <ul class="footer-link">
                <li><a href="#">Payment Options</a></li>
                <li><a href="#">Fee Schedule</a></li>
                <li><a href="#">Getting Started</a></li>
                <li><a href="#">Identity Verification</a></li>
                <li><a href="#">Card Verification</a></li>
              </ul>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
              <h3 class="footer-titel">Contact</h3>
              <ul class="address">
                <li>
                  <a href="#"><i class="lni-map-marker"></i> Jalan Lenteng Agung Raya, Jagakarsa, Kota Jakarta Selatan</a>
                </li>
                <li>
                  <a href="#"><i class="lni-phone-handset"></i> Hotline: 021-786.3191 </a>
                </li>
                <li>
                  <a href="#"><i class="lni-phone-handset"></i> Whatsapp: 0857.1624.3174 </a>
                </li>
                <li>
                  <a href="#"><i class="lni-envelope"></i> info@nurulfikri.ac.id</a>
                </li>
              </ul>
            </div>
          </div>
        </div>  
      </div> 
      <div id="copyright">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <div class="copyright-content">
                <p>Copyright © 2020 <a rel="nofollow" href="'https://uideck.com">UIdeck</a> All Right Reserved</p>
              </div>
            </div>
          </div>
        </div>
      </div>   
    </footer> 
    <!-- Footer Section End -->

    <!-- Go to Top Link -->
    <a href="#" class="back-to-top">
    	<i class="lni-arrow-up"></i>
    </a>
    
    <!-- Preloader -->
    <div id="preloader">
      <div class="loader" id="loader-1"></div>
    </div>
    <!-- End Preloader -->
    
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="<?php echo base_url('assets/js/jquery-min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/popper.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/owl.carousel.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/wow.js')?>"></script>
    <script src="<?php echo base_url('assets/js/jquery.nav.js')?>"></script>
    <script src="<?php echo base_url('assets/js/scrolling-nav.js')?>"></script>
    <script src="<?php echo base_url('assets/js/jquery.easing.min.js')?>"></script>  
    <script src="<?php echo base_url('assets/js/main.js')?>"></script>
    <script src="<?php echo base_url('assets/js/form-validator.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/contact-form-script.min.js')?>"></script>
      
  </body>
</html>
