<?php

require_once 'class_pasien.php';
require_once 'class_bmi_pasien.php';
class Bmi {
    public $tinggi;
    public $berat;
    public $nilaibmi;
    public $statusbmi;

    function __construct($tinggi, $berat,$nilaibmi, $statusbmi) {
        $this -> tinggi = "$tinggi";     
        $this -> berat = "$berat";     
        $this -> nilaibmi = "$nilaibmi";     
        $this -> statusbmi = "$statusbmi";     
    }
}

?>