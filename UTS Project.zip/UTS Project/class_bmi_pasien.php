<?php

require_once 'class_pasien.php';
require_once 'class_bmi.php';

class BmiPasien {
    public $pasien;
    public $bmi;
    public $tanggal;

    function __construct($pasien, $bmi, $tanggal)
    {
        $this -> pasien = $pasien;
        $this -> bmi = $bmi;
        $this -> tanggal = $tanggal;
    }

}
?>