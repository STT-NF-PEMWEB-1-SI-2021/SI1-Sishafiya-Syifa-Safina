<?php
require_once 'class_pasien.php';
require_once 'class_bmi.php';
require_once 'class_bmi_pasien.php';

// pasien 1
$pasien1 = new Pasien ("Rara", "Sumatra", "03 April 1998", "Rara.id@gmail.com", "P");

// pasien 2
$pasien2 = new Pasien ("Ahmad", "banjar", "25 september 2003", "ahmad.id@gmail.com", "L");

// pasien 3
$pasien3 = new Pasien ("Gani", "teras", "25 Agustus 1999", "gani.id@gmail.com", "L");

// bmi 1
$bmi1 = new Bmi("155", "50", 20.8, "Normal");

// bmi 2
$bmi2 = new Bmi("170", "40", 13.8, "Kurang Berat Badan");

// bmi 3
$bmi3 = new Bmi("170", "60", 20.8, "Normal");

// class bmi pasien
$bp1 = new BmiPasien ($pasien1, $bmi1, "22/03/2022");
$bp2 = new BmiPasien ($pasien2, $bmi2, "17/12/2022");
$bp3 = new BmiPasien ($pasien3, $bmi3, "12/03/2022");

$array = [$bp1, $bp2, $bp3];


?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>UTS Projects | STTNF</title>

    <!-- Google Font: Source Sans Pro -->
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback"
    />
    <!-- Font Awesome -->
    <link
      rel="stylesheet"
      href="plugins/fontawesome-free/css/all.min.css"
    />
    <!-- DataTables -->
    <link
      rel="stylesheet"
      href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css"
    />
    <link
      rel="stylesheet"
      href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css"
    />
    <link
      rel="stylesheet"
      href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css"
    />
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/adminlte.min.css" />
  </head>
  <body class="hold-transition sidebar-mini">
    <div class="wrapper">
      <!-- Navbar -->
      <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"
              ><i class="fas fa-bars"></i
            ></a>
          </li>
          <li class="nav-item d-none d-sm-inline-block">
            <a href="#" class="nav-link">Home</a>
          </li>
          <li class="nav-item d-none d-sm-inline-block">
            <a href="#" class="nav-link">Contact</a>
          </li>
        </ul>

        <!-- Right navbar links -->
        <ul class="navbar-nav ml-auto">
          <!-- Navbar Search -->
          <li class="nav-item">
            <a
              class="nav-link"
              data-widget="navbar-search"
              href="#"
              role="button"
            >
              <i class="fas fa-search"></i>
            </a>
            <div class="navbar-search-block">
              <form class="form-inline">
                <div class="input-group input-group-sm">
                  <input
                    class="form-control form-control-navbar"
                    type="search"
                    placeholder="Search"
                    aria-label="Search"
                  />
                  <div class="input-group-append">
                    <button class="btn btn-navbar" type="submit">
                      <i class="fas fa-search"></i>
                    </button>
                    <button
                      class="btn btn-navbar"
                      type="button"
                      data-widget="navbar-search"
                    >
                      <i class="fas fa-times"></i>
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </li>

          <!-- Messages Dropdown Menu -->
          <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
              <i class="far fa-comments"></i>
              <span class="badge badge-danger navbar-badge">3</span>
            </a>
            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
              <a href="#" class="dropdown-item">
                <!-- Message Start -->
                <div class="media">
                  <img
                    src="dist/img/user1-128x128.jpg"
                    alt="User Avatar"
                    class="img-size-50 mr-3 img-circle"
                  />
                  <div class="media-body">
                    <h3 class="dropdown-item-title">
                      Brad Diesel
                      <span class="float-right text-sm text-danger"
                        ><i class="fas fa-star"></i
                      ></span>
                    </h3>
                    <p class="text-sm">Call me whenever you can...</p>
                    <p class="text-sm text-muted">
                      <i class="far fa-clock mr-1"></i> 4 Hours Ago
                    </p>
                  </div>
                </div>
                <!-- Message End -->
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item">
                <!-- Message Start -->
                <div class="media">
                  <img
                    src="dist/img/user8-128x128.jpg"
                    alt="User Avatar"
                    class="img-size-50 img-circle mr-3"
                  />
                  <div class="media-body">
                    <h3 class="dropdown-item-title">
                      John Pierce
                      <span class="float-right text-sm text-muted"
                        ><i class="fas fa-star"></i
                      ></span>
                    </h3>
                    <p class="text-sm">I got your message bro</p>
                    <p class="text-sm text-muted">
                      <i class="far fa-clock mr-1"></i> 4 Hours Ago
                    </p>
                  </div>
                </div>
                <!-- Message End -->
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item">
                <!-- Message Start -->
                <div class="media">
                  <img
                    src="dist/img/user3-128x128.jpg"
                    alt="User Avatar"
                    class="img-size-50 img-circle mr-3"
                  />
                  <div class="media-body">
                    <h3 class="dropdown-item-title">
                      Nora Silvester
                      <span class="float-right text-sm text-warning"
                        ><i class="fas fa-star"></i
                      ></span>
                    </h3>
                    <p class="text-sm">The subject goes here</p>
                    <p class="text-sm text-muted">
                      <i class="far fa-clock mr-1"></i> 4 Hours Ago
                    </p>
                  </div>
                </div>
                <!-- Message End -->
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item dropdown-footer"
                >See All Messages</a
              >
            </div>
          </li>
          <!-- Notifications Dropdown Menu -->
          <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
              <i class="far fa-bell"></i>
              <span class="badge badge-warning navbar-badge">15</span>
            </a>
            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
              <span class="dropdown-item dropdown-header"
                >15 Notifications</span
              >
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item">
                <i class="fas fa-envelope mr-2"></i> 4 new messages
                <span class="float-right text-muted text-sm">3 mins</span>
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item">
                <i class="fas fa-users mr-2"></i> 8 friend requests
                <span class="float-right text-muted text-sm">12 hours</span>
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item">
                <i class="fas fa-file mr-2"></i> 3 new reports
                <span class="float-right text-muted text-sm">2 days</span>
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item dropdown-footer"
                >See All Notifications</a
              >
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-widget="fullscreen" href="#" role="button">
              <i class="fas fa-expand-arrows-alt"></i>
            </a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link"
              data-widget="control-sidebar"
              data-slide="true"
              href="#"
              role="button"
            >
              <i class="fas fa-th-large"></i>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.navbar -->

      <!-- Main Sidebar Container -->
      <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <!-- Brand Logo -->
        <a href="#" class="brand-link">
          <img
            src="dist/img/UTS projects.jpg"
            alt="UTS projects"
            class="brand-image img-circle elevation-3"
            style="opacity: 0.8"
          />
          <span class="brand-text font-weight-light">UTS Projects</span>
        </a>

        <!-- Sidebar -->
        <div class="sidebar">
          <!-- Sidebar user (optional) -->
          <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
              <img
                src="dist/img/safina1.jpg"
                class="img-circle elevation-2"
                alt="User Image"
              />
            </div>
            <div class="info">
              <a href="#" class="d-block">Sishafiya Syifa Safina</a>
            </div>
          </div>

          <!-- SidebarSearch Form -->
          <div class="form-inline">
            <div class="input-group" data-widget="sidebar-search">
              <input
                class="form-control form-control-sidebar"
                type="search"
                placeholder="Search"
                aria-label="Search"
              />
              <div class="input-group-append">
                <button class="btn btn-sidebar">
                  <i class="fas fa-search fa-fw"></i>
                </button>
              </div>
            </div>
          </div>

          <!-- Sidebar Menu -->
          <nav class="mt-2">
            <ul
              class="nav nav-pills nav-sidebar flex-column"
              data-widget="treeview"
              role="menu"
              data-accordion="false"
            >
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="nav-icon fas fa-tachometer-alt"></i>
                  <p>
                    Dashboard
                    <i class="right fas fa-angle-left"></i>
                  </p>
                </a>
                <ul class="nav nav-treeview">
                  <li class="nav-item">
                    <a href="praktikum/praktikum1.php" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 1</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="praktikum/praktikum2.php" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 2</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="praktikum/praktikum3.php" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 3</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="praktikum/praktikum4.php" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 4</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="praktikum/praktikum5.php" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 5</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="praktikum/praktikum6.php" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 6</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 7</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 8</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 9</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 10</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 11</p>
                    </a>
                  </li>
                </ul>
              </li>
              <li class="nav-item">
                <a href="." class="nav-link active">
                  <i class="nav-icon fas fa-users"></i>
                  <p>
                    Daftar Pasien
                    </p>
                </a>
              </li>
              <li class="nav-item">
                <a href="kalkulatorbmi.php" class="nav-link">
                  <i class="nav-icon fas fa-th"></i>
                  <p>
                    Kalkulator BMI
                  </p>
                </a>
              </li>
             
          </nav>
          <!-- /.sidebar-menu -->
        </div>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
                <h1>Daftar Pasien</h1>
              </div>
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active"></li>
                </ol>
              </div>
            </div>
          </div>
          <!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="container-fluid">
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <a href="." class="btn btn-success btn-sm shadow"
                      >Refresh</a
                    >
                    <a href="kalkulatorbmi.php" class="btn btn-primary btn-sm shadow"
                      >Tambah Data Pasien</a
                    >
                  </div>
                  <!-- /.card-header -->
                  <div class="card-body">
                    <table
                      id="example2"
                      class="table table-bordered table-hover"
                    >
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Nama</th>
                          <th>Tmpt Lahir</th>
                          <th>Tgl Lahir</th>
                          <th>Email</th>
                          <th>Gender</th>
                          <th>Berat Bdn (kg)</th>
                          <th>Tinggi Bdn (cm)</th>
                          <th>Tgl Periksa</th>
                          <th>Nilai Bmi</th>
                          <th>Stts Bmi</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody> 
                      <?php
                        $nomor = 1; 
                        foreach ($array as $obj) {
                          ?>
                        <tr>
                          <td><?= $nomor; ?></td>
                          <td><?= $obj -> pasien -> nama; ?></td>
                          <td><?= $obj -> pasien -> tmp_lahir; ?></td>
                          <td><?= $obj -> pasien -> tgl_lahir; ?></td>
                          <td><?= $obj -> pasien -> email; ?></td>
                          <td><?= $obj -> pasien -> gender; ?></td>
                          <td><?= $obj -> bmi -> berat; ?></td>
                          <td><?= $obj -> bmi -> tinggi; ?></td>
                          <td><?= $obj -> tanggal; ?></td>
                          <td><?= $obj -> bmi -> nilaibmi; ?></td>
                          <td><?= $obj -> bmi -> statusbmi; ?></td>
                          <td><div class="btn btn-danger btn-sm shadow disabled">Hapus</div></td>
                          <?php $nomor++;
                       }
                      ?>
                        </tr>
                        <?php
                        class Tampil {
                          function koneksi() {
                            $koneksi = mysqli_connect("localhost", "root", "", "data");
                            return $koneksi;
                          }
                        
                          function list() {
                            $konek = $this-> koneksi();
                            $query = mysqli_query($konek, "SELECT * FROM proyek1");
                            $nomor = 4;
                            while($data = mysqli_fetch_assoc($query)) {

                              ?>
                              <tr>
                                <td><?= $nomor;?> </td>
                                <td><?= $data['nama']; ?></td>
                                <td><?= $data['tempat_lahir']; ?></td>
                                <td><?= $data['tanggal_lahir']; ?></td>
                                <td><?= $data['email']; ?></td>
                                <td><?= $data['gender']; ?></td>
                                <td><?= $data['berat_badan']; ?></td>
                                <td><?= $data['tinggi_badan']; ?></td>
                                <td><?= $data['tanggal_periksa']; ?></td>
                                <td><?= $data['nilai_bmi']; ?></td>
                                <td><?= $data['status_bmi']; ?></td>
                                <td><a href="delete.php?id= <?= $data['id']; ?>" onclick="return confirm('Konfirmasi Untuk Menghapus!')" class="btn btn-sm btn-danger shadow">Hapus</a></td>
                              </tr>
                              <?= $nomor++; ?>
                              <?php
                              
                            }
                          }
                        }
                        $listobj = new Tampil();
                        $listobj ->list();                        
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->
          </div>
        </section>
        <!-- /.content -->
      </div>
      <!-- /.content-wrapper -->
      <footer class="main-footer">
        <div class="float-right d-none d-sm-block"><b>Version</b> 3.1.0</div>
        <strong
          >Copyright &copy; 2014-2021
          <a href="https://adminlte.io">AdminLTE.io</a>.</strong
        >
        All rights reserved.
      </footer>

      <!-- Control Sidebar -->
      <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
      </aside>
      <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- DataTables  & Plugins -->
    <script src="plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
    <script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
    <script src="plugins/jszip/jszip.min.js"></script>
    <script src="plugins/pdfmake/pdfmake.min.js"></script>
    <script src="plugins/pdfmake/vfs_fonts.js"></script>
    <script src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
    <script src="plugins/datatables-buttons/js/buttons.print.min.js"></script>
    <script src="plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/adminlte.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    <!-- Page specific script -->
    <script>
      $(function () {
        $("#example1")
          .DataTable({
            responsive: true,
            lengthChange: false,
            autoWidth: false,
            buttons: ["copy", "csv", "excel", "pdf", "print", "colvis"],
          })
          .buttons()
          .container()
          .appendTo("#example1_wrapper .col-md-6:eq(0)");
        $("#example2").DataTable({
          paging: true,
          lengthChange: false,
          searching: false,
          ordering: true,
          info: true,
          autoWidth: false,
          responsive: true,
        });
      });
    </script>
  </body>
</html>
