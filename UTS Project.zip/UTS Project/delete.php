<?php

$conn = mysqli_connect("localhost", "root", "", "data");

    $id = $_GET['id'];
    $query = "DELETE FROM proyek1 WHERE id = $id";

    $hasil = mysqli_query($conn, $query);

    if ($hasil > 0 ) {
        echo"<script>
        alert('Data Berhasil Dihapus');
        document.location.href = '.';
             </script>";
    } else {
        echo"<script>
        alert('Data Gagal Dihapus');
        document.location.href = '.';
             </script>";
    }

?>