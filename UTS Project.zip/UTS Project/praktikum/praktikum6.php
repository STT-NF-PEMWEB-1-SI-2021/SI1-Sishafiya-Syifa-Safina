<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Praktikum 6</title>

    <!-- Google Font: Source Sans Pro -->
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback"
    />
    <!-- Font Awesome -->
    <link
      rel="stylesheet"
      href="../plugins/fontawesome-free/css/all.min.css"
    />
    <!-- daterange picker -->
    <link
      rel="stylesheet"
      href="../plugins/daterangepicker/daterangepicker.css"
    />
    <!-- iCheck for checkboxes and radio inputs -->
    <link
      rel="stylesheet"
      href="../plugins/icheck-bootstrap/icheck-bootstrap.min.css"
    />
    <!-- Bootstrap Color Picker -->
    <link
      rel="stylesheet"
      href="../plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css"
    />
    <!-- Tempusdominus Bootstrap 4 -->
    <link
      rel="stylesheet"
      href="../plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css"
    />
    <!-- Select2 -->
    <link rel="stylesheet" href="../plugins/select2/css/select2.min.css" />
    <link
      rel="stylesheet"
      href="../plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css"
    />
    <!-- Bootstrap4 Duallistbox -->
    <link
      rel="stylesheet"
      href="../plugins/bootstrap4-duallistbox/bootstrap-duallistbox.min.css"
    />
    <!-- BS Stepper -->
    <link
      rel="stylesheet"
      href="../plugins/bs-stepper/css/bs-stepper.min.css"
    />
    <!-- dropzonejs -->
    <link rel="stylesheet" href="../plugins/dropzone/min/dropzone.min.css" />
    <!-- Theme style -->
    <link rel="stylesheet" href="../dist/css/adminlte.min.css" />
  </head>
  <body class="hold-transition sidebar-mini">
    <div class="wrapper">
      <!-- Navbar -->
      <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"
              ><i class="fas fa-bars"></i
            ></a>
          </li>
          <li class="nav-item d-none d-sm-inline-block">
            <a href="../." class="nav-link">Home</a>
          </li>
          <li class="nav-item d-none d-sm-inline-block">
            <a href="#" class="nav-link">Contact</a>
          </li>
        </ul>

        <!-- Right navbar links -->
        <ul class="navbar-nav ml-auto">
          <!-- Navbar Search -->
          <li class="nav-item">
            <a
              class="nav-link"
              data-widget="navbar-search"
              href="#"
              role="button"
            >
              <i class="fas fa-search"></i>
            </a>
            <div class="navbar-search-block">
              <form class="form-inline">
                <div class="input-group input-group-sm">
                  <input
                    class="form-control form-control-navbar"
                    type="search"
                    placeholder="Search"
                    aria-label="Search"
                  />
                  <div class="input-group-append">
                    <button class="btn btn-navbar" type="submit">
                      <i class="fas fa-search"></i>
                    </button>
                    <button
                      class="btn btn-navbar"
                      type="button"
                      data-widget="navbar-search"
                    >
                      <i class="fas fa-times"></i>
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </li>

          <!-- Messages Dropdown Menu -->
          <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
              <i class="far fa-comments"></i>
              <span class="badge badge-danger navbar-badge">3</span>
            </a>
            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
              <a href="#" class="dropdown-item">
                <!-- Message Start -->
                <div class="media">
                  <img
                    src="../dist/img/user1-128x128.jpg"
                    alt="User Avatar"
                    class="img-size-50 mr-3 img-circle"
                  />
                  <div class="media-body">
                    <h3 class="dropdown-item-title">
                      Brad Diesel
                      <span class="float-right text-sm text-danger"
                        ><i class="fas fa-star"></i
                      ></span>
                    </h3>
                    <p class="text-sm">Call me whenever you can...</p>
                    <p class="text-sm text-muted">
                      <i class="far fa-clock mr-1"></i> 4 Hours Ago
                    </p>
                  </div>
                </div>
                <!-- Message End -->
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item">
                <!-- Message Start -->
                <div class="media">
                  <img
                    src="../dist/img/user8-128x128.jpg"
                    alt="User Avatar"
                    class="img-size-50 img-circle mr-3"
                  />
                  <div class="media-body">
                    <h3 class="dropdown-item-title">
                      John Pierce
                      <span class="float-right text-sm text-muted"
                        ><i class="fas fa-star"></i
                      ></span>
                    </h3>
                    <p class="text-sm">I got your message bro</p>
                    <p class="text-sm text-muted">
                      <i class="far fa-clock mr-1"></i> 4 Hours Ago
                    </p>
                  </div>
                </div>
                <!-- Message End -->
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item">
                <!-- Message Start -->
                <div class="media">
                  <img
                    src="../dist/img/user3-128x128.jpg"
                    alt="User Avatar"
                    class="img-size-50 img-circle mr-3"
                  />
                  <div class="media-body">
                    <h3 class="dropdown-item-title">
                      Nora Silvester
                      <span class="float-right text-sm text-warning"
                        ><i class="fas fa-star"></i
                      ></span>
                    </h3>
                    <p class="text-sm">The subject goes here</p>
                    <p class="text-sm text-muted">
                      <i class="far fa-clock mr-1"></i> 4 Hours Ago
                    </p>
                  </div>
                </div>
                <!-- Message End -->
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item dropdown-footer"
                >See All Messages</a
              >
            </div>
          </li>
          <!-- Notifications Dropdown Menu -->
          <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
              <i class="far fa-bell"></i>
              <span class="badge badge-warning navbar-badge">15</span>
            </a>
            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
              <span class="dropdown-item dropdown-header"
                >15 Notifications</span
              >
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item">
                <i class="fas fa-envelope mr-2"></i> 4 new messages
                <span class="float-right text-muted text-sm">3 mins</span>
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item">
                <i class="fas fa-users mr-2"></i> 8 friend requests
                <span class="float-right text-muted text-sm">12 hours</span>
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item">
                <i class="fas fa-file mr-2"></i> 3 new reports
                <span class="float-right text-muted text-sm">2 days</span>
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item dropdown-footer"
                >See All Notifications</a
              >
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-widget="fullscreen" href="#" role="button">
              <i class="fas fa-expand-arrows-alt"></i>
            </a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link"
              data-widget="control-sidebar"
              data-slide="true"
              href="#"
              role="button"
            >
              <i class="fas fa-th-large"></i>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.navbar -->

      <!-- Main Sidebar Container -->
      <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <!-- Brand Logo -->
        <a href="#" class="brand-link">
          <img
            src="../dist/img/UTS projects.jpg"
            alt="UTS Projects"
            class="brand-image img-circle elevation-3"
            style="opacity: 0.8"
          />
          <span class="brand-text font-weight-light">UTS Projects</span>
        </a>

        <!-- Sidebar -->
        <div class="sidebar">
          <!-- Sidebar user (optional) -->
          <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
              <img
                src="../dist/img/safina1.jpg"
                class="img-circle elevation-2"
                alt="User Image"
              />
            </div>
            <div class="info">
              <a href="#" class="d-block">Sishafiya Syifa Safina</a>
            </div>
          </div>

          <!-- SidebarSearch Form -->
          <div class="form-inline">
            <div class="input-group" data-widget="sidebar-search">
              <input
                class="form-control form-control-sidebar"
                type="search"
                placeholder="Search"
                aria-label="Search"
              />
              <div class="input-group-append">
                <button class="btn btn-sidebar">
                  <i class="fas fa-search fa-fw"></i>
                </button>
              </div>
            </div>
          </div>

          <!-- Sidebar Menu -->
          <nav class="mt-2">
            <ul
              class="nav nav-pills nav-sidebar flex-column"
              data-widget="treeview"
              role="menu"
              data-accordion="false"
            >
              <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
              <li class="nav-item menu-open">
                <a href="#" class="nav-link">
                  <i class="nav-icon fas fa-tachometer-alt"></i>
                  <p>
                    Dashboard
                    <i class="right fas fa-angle-left"></i>
                  </p>
                </a>
                <ul class="nav nav-treeview">
                  <li class="nav-item">
                    <a href="praktikum1.php" class="nav-link ">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 1</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="praktikum2.php" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 2</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="praktikum3.php" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 3</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="praktikum4.php" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 4</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="praktikum5.php" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 5</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link active">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 6</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 7</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 8</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 9</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 10</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Praktikum 11</p>
                    </a>
                  </li>
                </ul>
              </li>
              <li class="nav-item">
                <a href="../." class="nav-link">
                  <i class="nav-icon fas fa-users"></i>
                  <p>
                    Daftar Pasien
                  </p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../kalkulatorbmi.php" class="nav-link">
                  <i class="nav-icon fas fa-th"></i>
                  <p>
                    Kalkulator BMI
                  </p>
                </a>
              </li>
             </nav>
          <!-- /.sidebar-menu -->
        </div>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
                <h1>Daftar Tugas Praktikum 6</h1>
              </div>
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active">Praktikum 6</li>
                </ol>
              </div>
            </div>
          </div>
          <!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="container-fluid">
            <div class="row justify-content-center">
              <!-- /.col (left) -->
              <div class="col-md-6">
                <div class="card card-primary">
                  <div class="card-body">
                      <h4>BMI.php</h4>
                      <!-- HTML generated using hilite.me --><div style="background: #ffffff; overflow:auto;width:auto; height: 650px; border:solid gray;border-width:.1em .1em .1em .8em;padding:.2em .6em;"><table><tr><td><pre style="margin: 0; line-height: 125%">  1
  2
  3
  4
  5
  6
  7
  8
  9
 10
 11
 12
 13
 14
 15
 16
 17
 18
 19
 20
 21
 22
 23
 24
 25
 26
 27
 28
 29
 30
 31
 32
 33
 34
 35
 36
 37
 38
 39
 40
 41
 42
 43
 44
 45
 46
 47
 48
 49
 50
 51
 52
 53
 54
 55
 56
 57
 58
 59
 60
 61
 62
 63
 64
 65
 66
 67
 68
 69
 70
 71
 72
 73
 74
 75
 76
 77
 78
 79
 80
 81
 82
 83
 84
 85
 86
 87
 88
 89
 90
 91
 92
 93
 94
 95
 96
 97
 98
 99
100
101
102
103
104
105
106
107
108
109
110
111
112
113
114
115
116
117
118
119
120
121
122
123
124
125
126
127
128
129
130
131
132
133
134
135
136
137
138
139
140
141
142
143
144
145
146
147
148</pre></td><td><pre style="margin: 0; line-height: 125%">&lt;!DOCTYPE html&gt;
&lt;html lang=&quot;en&quot;&gt;
    &lt;head&gt;
        &lt;meta charset=&quot;UTF-8&quot;&gt;
        &lt;meta http-equiv=&quot;X-UA-Compatible&quot; content=&quot;IE=edge&quot;&gt;
        &lt;meta name=&quot;viewport&quot; content=&quot;width=device-width, initial-scale=1.0&quot;&gt;
        &lt;link rel=&quot;stylesheet&quot; href=&quot;https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css&quot;&gt; 
        &lt;link rel=&quot;stylesheet&quot; href=&quot;https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css&quot;&gt;
        &lt;title&gt;Kalkulator BMI&lt;/title&gt;

        &lt;style&gt;
            body{
                margin-top: 50px;
                margin-right: 50px;
                margin-left: 50px;
            }
            form{
                margin-right: 50px;
                margin-left: 50px;
            }
            th{
                text-align: center;
                background-color: #007256;
                color: white;
            }
            h3{
                text-align: center;
            }
            tbody{
                text-align: center;
            }
        &lt;/style&gt;
    &lt;/head&gt;

    &lt;body&gt;
        &lt;h3&gt;KALKULATOR BMI&lt;/h3&gt;
        &lt;hr/&gt;&lt;br/&gt;
        &lt;form action = &quot;#table&quot; method = &quot;POST&quot;&gt;
            &lt;div class=&quot;form-group row&quot;&gt;
                &lt;label for=&quot;kode&quot; class=&quot;col-4 col-form-label&quot;&gt;Kode Pasien&lt;/label&gt; 
                &lt;div class=&quot;col-8&quot;&gt;
                &lt;input id=&quot;kode&quot; name=&quot;kode&quot; placeholder=&quot;Masukkan Kode&quot; type=&quot;text&quot; class=&quot;form-control&quot;&gt;
                &lt;/div&gt;
            &lt;/div&gt;
            &lt;div class=&quot;form-group row&quot;&gt;
                &lt;label for=&quot;pasien&quot; class=&quot;col-4 col-form-label&quot;&gt;Nama Pasien&lt;/label&gt; 
                &lt;div class=&quot;col-8&quot;&gt;
                &lt;input id=&quot;pasien&quot; name=&quot;pasien&quot; placeholder=&quot;Masukkan Nama Lengkap&quot; type=&quot;text&quot; class=&quot;form-control&quot;&gt;
                &lt;/div&gt;
            &lt;/div&gt;
            &lt;div class=&quot;form-group row&quot;&gt;
                &lt;label for=&quot;tanggal&quot; class=&quot;col-4 col-form-label&quot;&gt;Tangal Periksa&lt;/label&gt; 
                &lt;div class=&quot;col-8&quot;&gt;
                &lt;input id=&quot;tanggal&quot; name=&quot;tanggal&quot; placeholder=&quot;dd-mm-yyyy&quot; type=&quot;text&quot; class=&quot;form-control&quot; aria-describedby=&quot;tanggalHelpBlock&quot;&gt; 
                &lt;span id=&quot;tanggalHelpBlock&quot; class=&quot;form-text text-muted&quot;&gt;Masukkan tanggal sesuai tanggal-bulan-tahun&lt;/span&gt;
                &lt;/div&gt;
            &lt;/div&gt;
            &lt;div class=&quot;form-group row&quot;&gt;
                &lt;label class=&quot;col-4&quot;&gt;Gender&lt;/label&gt; 
                &lt;div class=&quot;col-8&quot;&gt;
                &lt;div class=&quot;custom-control custom-radio custom-control-inline&quot;&gt;
                    &lt;input name=&quot;gender&quot; id=&quot;gender_0&quot; type=&quot;radio&quot; class=&quot;custom-control-input&quot; value=&quot;L&quot;&gt; 
                    &lt;label for=&quot;gender_0&quot; class=&quot;custom-control-label&quot;&gt;Pria&lt;/label&gt;
                &lt;/div&gt;
                &lt;div class=&quot;custom-control custom-radio custom-control-inline&quot;&gt;
                    &lt;input name=&quot;gender&quot; id=&quot;gender_1&quot; type=&quot;radio&quot; class=&quot;custom-control-input&quot; value=&quot;P&quot;&gt; 
                    &lt;label for=&quot;gender_1&quot; class=&quot;custom-control-label&quot;&gt;Wanita&lt;/label&gt;
                &lt;/div&gt;
                &lt;/div&gt;
            &lt;/div&gt;
            &lt;div class=&quot;form-group row&quot;&gt;
                &lt;label for=&quot;bb&quot; class=&quot;col-4 col-form-label&quot;&gt;Berat Badan&lt;/label&gt; 
                &lt;div class=&quot;col-8&quot;&gt;
                &lt;input id=&quot;bb&quot; name=&quot;bb&quot; placeholder=&quot;Masukkan Berat Badan (kg)&quot; type=&quot;text&quot; class=&quot;form-control&quot;&gt;
                &lt;/div&gt;
            &lt;/div&gt;
            &lt;div class=&quot;form-group row&quot;&gt;
                &lt;label for=&quot;tb&quot; class=&quot;col-4 col-form-label&quot;&gt;Tinggi Badan&lt;/label&gt; 
                &lt;div class=&quot;col-8&quot;&gt;
                &lt;input id=&quot;tb&quot; name=&quot;tb&quot; placeholder=&quot;Masukkan Tinggi Badan (m)&quot; type=&quot;text&quot; class=&quot;form-control&quot;&gt;
                &lt;/div&gt;
            &lt;/div&gt; 
            &lt;div class=&quot;form-group row&quot;&gt;
                &lt;div class=&quot;offset-4 col-8&quot;&gt;
                &lt;button name=&quot;submit&quot; type=&quot;submit&quot; class=&quot;btn btn-success&quot;&gt;Count&lt;/button&gt;
                &lt;/div&gt;
            &lt;/div&gt;
        &lt;/form&gt;
    
        <span style="color: #0000ff">&lt;?php</span>
            <span style="color: #0000ff">require_once</span> <span style="color: #a31515">&quot;class_bmi.php&quot;</span>;
            <span style="color: #0000ff">require_once</span> <span style="color: #a31515">&quot;class_pasien.php&quot;</span>;

            $_kode = $_POST[<span style="color: #a31515">&#39;kode&#39;</span>];
            $_nama = $_POST[<span style="color: #a31515">&#39;pasien&#39;</span>];
            $_tanggal = $_POST[<span style="color: #a31515">&#39;tanggal&#39;</span>];
            $_gender = $_POST[<span style="color: #a31515">&#39;gender&#39;</span>];
            $_berat = $_POST[<span style="color: #a31515">&#39;bb&#39;</span>];
            $_tinggi = $_POST[<span style="color: #a31515">&#39;tb&#39;</span>];

            $status = <span style="color: #0000ff">new</span> bmi($_berat, $_tinggi);
    
            $dp1 = [<span style="color: #a31515">&#39;no&#39;</span>=&gt;1,<span style="color: #a31515">&#39;Tanggal_Periksa&#39;</span>=&gt;<span style="color: #a31515">&#39;2022-01-10&#39;</span>, <span style="color: #a31515">&#39;Kode_Pasien&#39;</span> =&gt; <span style="color: #a31515">&#39;P001&#39;</span>,<span style="color: #a31515">&#39;Nama_Pasien&#39;</span>=&gt;<span style="color: #a31515">&#39;Ahmad&#39;</span>,<span style="color: #a31515">&#39;Gender&#39;</span>=&gt; <span style="color: #a31515">&#39;L&#39;</span>,<span style="color: #a31515">&#39;Berat&#39;</span>=&gt;69.8, <span style="color: #a31515">&#39;Tinggi&#39;</span>=&gt;1.69, <span style="color: #a31515">&#39;Nilai_BMI&#39;</span>=&gt;24.7, <span style="color: #a31515">&#39;Status_BMI&#39;</span>=&gt;<span style="color: #a31515">&#39;Kelebihan Berat Badan&#39;</span>];
            $dp2 = [<span style="color: #a31515">&#39;no&#39;</span>=&gt;2,<span style="color: #a31515">&#39;Tanggal_Periksa&#39;</span>=&gt;<span style="color: #a31515">&#39;2022-01-10&#39;</span>, <span style="color: #a31515">&#39;Kode_Pasien&#39;</span> =&gt; <span style="color: #a31515">&#39;P002&#39;</span>,<span style="color: #a31515">&#39;Nama_Pasien&#39;</span>=&gt;<span style="color: #a31515">&#39;Rina&#39;</span>,<span style="color: #a31515">&#39;Gender&#39;</span>=&gt; <span style="color: #a31515">&#39;P&#39;</span>,<span style="color: #a31515">&#39;Berat&#39;</span>=&gt;55.3, <span style="color: #a31515">&#39;Tinggi&#39;</span>=&gt;1.65, <span style="color: #a31515">&#39;Nilai_BMI&#39;</span>=&gt;20.3, <span style="color: #a31515">&#39;Status_BMI&#39;</span>=&gt;<span style="color: #a31515">&#39;Normal (Ideal)&#39;</span>];
            $dp3 = [<span style="color: #a31515">&#39;no&#39;</span>=&gt;3,<span style="color: #a31515">&#39;Tanggal_Periksa&#39;</span>=&gt;<span style="color: #a31515">&#39;2022-01-11&#39;</span>, <span style="color: #a31515">&#39;Kode_Pasien&#39;</span> =&gt; <span style="color: #a31515">&#39;P003&#39;</span>,<span style="color: #a31515">&#39;Nama_Pasien&#39;</span>=&gt;<span style="color: #a31515">&#39;Lutfi&#39;</span>,<span style="color: #a31515">&#39;Gender&#39;</span>=&gt; <span style="color: #a31515">&#39;L&#39;</span>,<span style="color: #a31515">&#39;Berat&#39;</span>=&gt;45.2, <span style="color: #a31515">&#39;Tinggi&#39;</span>=&gt;1.71, <span style="color: #a31515">&#39;Nilai_BMI&#39;</span>=&gt;15.4, <span style="color: #a31515">&#39;Status_BMI&#39;</span>=&gt;<span style="color: #a31515">&#39;Kekurangan Berat Badan&#39;</span>];
            $dp4 = [<span style="color: #a31515">&#39;no&#39;</span>=&gt;1,<span style="color: #a31515">&#39;Tanggal_Periksa&#39;</span>=&gt; $_tanggal, <span style="color: #a31515">&#39;Kode_Pasien&#39;</span> =&gt; $_kode,<span style="color: #a31515">&#39;Nama_Pasien&#39;</span>=&gt;$_nama,<span style="color: #a31515">&#39;Gender&#39;</span>=&gt; $_gender,<span style="color: #a31515">&#39;Berat&#39;</span>=&gt;$_berat, <span style="color: #a31515">&#39;Tinggi&#39;</span>=&gt;$_tinggi, <span style="color: #a31515">&#39;Nilai_BMI&#39;</span>=&gt;$status-&gt;getnilaiBMI(), <span style="color: #a31515">&#39;Status_BMI&#39;</span>=&gt;$status-&gt;getstatusBMI()];
            $ar_data = [$dp1, $dp2, $dp3, $dp4];
        <span style="color: #0000ff">?&gt;</span>

            &lt;br/&gt;&lt;hr/&gt;&lt;br/&gt;
            &lt;h3&gt;Data Pasien&lt;/h3&gt;
                
            &lt;table class=&quot;table table-bordered&quot; id=&quot;table&quot;&gt;
            &lt;thead class=&quot;table-info&quot;&gt;
                &lt;tr&gt;
                &lt;th&gt;No&lt;/th&gt;
                &lt;th&gt;Kode Pasien&lt;/th&gt;
                &lt;th&gt;Nama Pasien&lt;/th&gt;
                &lt;th&gt;Tanggal Periksa&lt;/th&gt;
                &lt;th&gt;Gender&lt;/th&gt;
                &lt;th&gt;Berat (kg)&lt;/th&gt;
                &lt;th&gt;Tinggi (m)&lt;/th&gt;
                &lt;th&gt;Nilai BMI&lt;/th&gt;
                &lt;th&gt;Status BMI&lt;/th&gt;
                &lt;/tr&gt;
            &lt;/thead&gt;
            &lt;tbody&gt;

            <span style="color: #0000ff">&lt;?php</span>
            $nomor = 1;
            <span style="color: #0000ff">foreach</span>($ar_data <span style="color: #0000ff">as</span> $data){
                <span style="color: #0000ff">echo</span> <span style="color: #a31515">&#39;&lt;tr&gt;&#39;</span>;
                <span style="color: #0000ff">echo</span> <span style="color: #a31515">&#39;&lt;td&gt;&#39;</span>.$nomor.<span style="color: #a31515">&#39;&lt;/td&gt;&#39;</span>;
                <span style="color: #0000ff">echo</span> <span style="color: #a31515">&#39;&lt;td&gt;&#39;</span>.$data[<span style="color: #a31515">&#39;Tanggal_Periksa&#39;</span>].<span style="color: #a31515">&#39;&lt;/td&gt;&#39;</span>;
                <span style="color: #0000ff">echo</span> <span style="color: #a31515">&#39;&lt;td&gt;&#39;</span>.$data[<span style="color: #a31515">&#39;Kode_Pasien&#39;</span>].<span style="color: #a31515">&#39;&lt;/td&gt;&#39;</span>;
                <span style="color: #0000ff">echo</span> <span style="color: #a31515">&#39;&lt;td&gt;&#39;</span>.$data[<span style="color: #a31515">&#39;Nama_Pasien&#39;</span>].<span style="color: #a31515">&#39;&lt;/td&gt;&#39;</span>;
                <span style="color: #0000ff">echo</span> <span style="color: #a31515">&#39;&lt;td&gt;&#39;</span>.$data[<span style="color: #a31515">&#39;Gender&#39;</span>].<span style="color: #a31515">&#39;&lt;/td&gt;&#39;</span>;
                <span style="color: #0000ff">echo</span> <span style="color: #a31515">&#39;&lt;td&gt;&#39;</span>.$data[<span style="color: #a31515">&#39;Berat&#39;</span>].<span style="color: #a31515">&#39;&lt;/td&gt;&#39;</span>;
                <span style="color: #0000ff">echo</span> <span style="color: #a31515">&#39;&lt;td&gt;&#39;</span>.$data[<span style="color: #a31515">&#39;Tinggi&#39;</span>].<span style="color: #a31515">&#39;&lt;/td&gt;&#39;</span>;
                <span style="color: #0000ff">echo</span> <span style="color: #a31515">&#39;&lt;td&gt;&#39;</span>.$data[<span style="color: #a31515">&#39;Nilai_BMI&#39;</span>].<span style="color: #a31515">&#39;&lt;/td&gt;&#39;</span>;
                <span style="color: #0000ff">echo</span> <span style="color: #a31515">&#39;&lt;td&gt;&#39;</span>.$data[<span style="color: #a31515">&#39;Status_BMI&#39;</span>].<span style="color: #a31515">&#39;&lt;/td&gt;&#39;</span>;
                $nomor++;
            }
            <span style="color: #0000ff">?&gt;</span>
        &lt;/tbody&gt;

    &lt;/body&gt;
&lt;/html&gt;
</pre></td></tr></table></div>

                     </div>
                  </div>
                </div>
              <div class="col-md-6">
                <div class="card card-primary">
                  <div class="card-body">
                      <h4>class_BMI.php</h4>
                      <!-- HTML generated using hilite.me --><div style="background: #ffffff; overflow:auto;width:auto;border:solid gray;border-width:.1em .1em .1em .8em;padding:.2em .6em;"><table><tr><td><pre style="margin: 0; line-height: 125%"> 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34</pre></td><td><pre style="margin: 0; line-height: 125%"><span style="color: #0000ff">&lt;?php</span>
    <span style="color: #0000ff">require_once</span> <span style="color: #a31515">&quot;class_bmipasien.php&quot;</span>;

    <span style="color: #0000ff">class</span> <span style="color: #2b91af">BMI</span> <span style="color: #0000ff">extends</span> BMIPasien{
        <span style="color: #0000ff">public</span> $bb;
        <span style="color: #0000ff">public</span> $tb;
    
        <span style="color: #0000ff">public</span> <span style="color: #0000ff">function</span> __construct($bb, $tb){
            $this -&gt; berat = $bb;
            $this -&gt; tinggi = $tb;
        }
    
        <span style="color: #0000ff">function</span> getnilaiBMI(){
            <span style="color: #0000ff">return</span> $this-&gt;bmi = $this-&gt;berat / ($this-&gt;tinggi * $this-&gt;tinggi);
        }
    
        <span style="color: #0000ff">function</span> getstatusBMI(){
    
            <span style="color: #0000ff">if</span> ($this-&gt;bmi &gt;= 30){
                <span style="color: #0000ff">return</span> <span style="color: #a31515">&quot;Kegemukan (obesitas)&quot;</span>;
            }
            <span style="color: #0000ff">else</span> <span style="color: #0000ff">if</span> ($this-&gt;bmi &gt;= 25){
                <span style="color: #0000ff">return</span> <span style="color: #a31515">&quot;Kelebihan berat badan&quot;</span>;
            }
            <span style="color: #0000ff">else</span> <span style="color: #0000ff">if</span> ($this-&gt;bmi &gt;=18.5){
                <span style="color: #0000ff">return</span> <span style="color: #a31515">&quot;Normal (ideal)&quot;</span>;
            }
            <span style="color: #0000ff">else</span> <span style="color: #0000ff">if</span>($this-&gt;bmi &lt; 18.5){
                <span style="color: #0000ff">return</span> <span style="color: #a31515">&quot;Kekurangan berat badan&quot;</span>;
            }
        }
    
    }
<span style="color: #0000ff">?&gt;</span>
</pre></td></tr></table></div>

                     </div>
                  </div>
                </div>
              </div>
            <div class="row justify-content-center">
              <!-- /.col (left) -->
              <div class="col-md-6">
                <div class="card card-primary">
                  <div class="card-body">
                      <h4>class_BMIPasien.php</h4>
                      <!-- HTML generated using hilite.me --><div style="background: #ffffff; overflow:auto;width:auto;border:solid gray;border-width:.1em .1em .1em .8em;padding:.2em .6em;"><table><tr><td><pre style="margin: 0; line-height: 125%"> 1
 2
 3
 4
 5
 6
 7
 8
 9
10</pre></td><td><pre style="margin: 0; line-height: 125%"><span style="color: #0000ff">&lt;?php</span>

<span style="color: #0000ff">class</span> <span style="color: #2b91af">BMIPasien</span>{
    <span style="color: #0000ff">public</span> $no;
    <span style="color: #0000ff">public</span> $bmi;
    <span style="color: #0000ff">public</span> $tanggal;
    <span style="color: #0000ff">public</span> $pasien;
}

<span style="color: #0000ff">?&gt;</span>
</pre></td></tr></table></div>

                     </div>
                  </div>
                </div>
              <div class="col-md-6">
                <div class="card card-primary">
                  <div class="card-body">
                      <h4>class_Pasien.php</h4>
                      <!-- HTML generated using hilite.me --><div style="background: #ffffff; overflow:auto;width:auto;border:solid gray;border-width:.1em .1em .1em .8em;padding:.2em .6em;"><table><tr><td><pre style="margin: 0; line-height: 125%"> 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18</pre></td><td><pre style="margin: 0; line-height: 125%"><span style="color: #0000ff">&lt;?php</span>
    <span style="color: #0000ff">class</span> <span style="color: #2b91af">pasien</span>{
        <span style="color: #0000ff">public</span> $no;
        <span style="color: #0000ff">public</span> $kode;
        <span style="color: #0000ff">public</span> $nama;
        <span style="color: #0000ff">public</span> $tmp_lahir;
        <span style="color: #0000ff">public</span> $tgl_lahir;
        <span style="color: #0000ff">public</span> $email;
        <span style="color: #0000ff">public</span> $gender;
    
        <span style="color: #0000ff">public</span> <span style="color: #0000ff">function</span> __construct($kode, $nama, $gender){
            $this-&gt; kode = $kode;
            $this-&gt; nama = $nama;
            $this-&gt; gender = $gender;
        }
    }
    
<span style="color: #0000ff">?&gt;</span>
</pre></td></tr></table></div>

                     </div>
                  </div>
                </div>
              </div>
            </div>
        </section>
        <!-- /.content -->
      </div>
      <!-- /.content-wrapper -->
      <footer class="main-footer">
        <div class="float-right d-none d-sm-block"><b>Version</b> 3.1.0</div>
        <strong
          >Copyright &copy; 2014-2021
          <a href="https://adminlte.io">AdminLTE.io</a>.</strong
        >
        All rights reserved.
      </footer>

      <!-- Control Sidebar -->
      <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
      </aside>
      <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="../plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Select2 -->
    <script src="../plugins/select2/js/select2.full.min.js"></script>
    <!-- jquery-validation -->
    <script src="../plugins/jquery-validation/jquery.validate.min.js"></script>
    <script src="../plugins/jquery-validation/additional-methods.min.js"></script>
    <!-- Bootstrap4 Duallistbox -->
    <script src="../plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
    <!-- InputMask -->
    <script src="../plugins/moment/moment.min.js"></script>
    <script src="../plugins/inputmask/jquery.inputmask.min.js"></script>
    <!-- date-range-picker -->
    <script src="../plugins/daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap color picker -->
    <script src="../plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
    <!-- Tempusdominus Bootstrap 4 -->
    <script src="../plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
    <!-- Bootstrap Switch -->
    <script src="../plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
    <!-- BS-Stepper -->
    <script src="../plugins/bs-stepper/js/bs-stepper.min.js"></script>
    <!-- dropzonejs -->
    <script src="../plugins/dropzone/min/dropzone.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../dist/js/adminlte.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../dist/js/demo.js"></script>
    <!-- Page specific script -->
    <script src="date.js"></script>
  </body>
</html>
